# Cosmodétecteur — pilotage en Python
# Adaptation du logiciel « Roue Cosmique » [Sciences à l'École, CPPM]
# [Michel Jevaud, Marta Rodo Bordera, 2011] pour le Cosmodétecteur [José Busto] ;
# version Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
#
# Ce programme est un logiciel libre : vous pouvez le redistribuer et/ou le
# modifier selon les termes de la Licence publique générale GNU (GPL) publiée
# par la Free Software Foundation, version 3 ou (à votre choix) toute version
# ultérieure. Il est distribué SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Communication avec le boîtier électronique du cosmodétecteur (roue cosmique CPPM).

Protocole retrouvé à partir des sous-VI LabVIEW de « KA2.llb » (programme
« Roue Cosmique », M. Jevaud / M. Rodo Bordera, CPPM 2011) :

  * liaison série 9600 bauds, 8 bits, sans parité, 1 bit de stop, sans contrôle de flux ;
  * chaque échange = 6 octets envoyés puis 6 octets reçus :
        '#'  Commande  Data1  Data2  Data3  '?'
    Data1 = numéro de voie / de fonction (0 = PM1 ...), Data2/Data3 = valeur
    sur 12 ou 16 bits (poids fort, poids faible) ;
  * la réponse a la même forme ; pour une lecture, la valeur est
    réponse[3] * 256 + réponse[4].
"""

import math
import random
import threading
import time

# --- Codes de commande -------------------------------------------------------
CMD_SEUIL = 0          # programmation seuil DAC          (Data1 = voie)
CMD_LIRE_VOIE = 1      # lecture compteur voie            (Data1 = voie 0..3)
CMD_RAZ_VOIE = 2       # remise à zéro compteur voie
CMD_LIRE_FONCTION = 3  # lecture compteur fonction        (Data1 = fonction 0..8)
CMD_RAZ_FONCTION = 4   # remise à zéro compteur fonction
CMD_LIRE_VIEMUON = 5   # lecture compteur vie du muon     (Data1 = 0 ou 1)
CMD_RAZ_VIEMUON = 6    # remise à zéro compteur vie du muon
CMD_ECRIRE_HT = 7      # programmation haute tension      (Data1 = voie)
CMD_LIRE_HT = 8        # lecture haute tension            (Data1 = voie)

NOMS_VOIES = ["PM1", "PM2", "PM3", "PM4"]
NOMS_FONCTIONS = ["PM1xPM2", "PM1xPM3", "PM1xPM4", "PM2xPM3", "PM2xPM4",
                  "PM3xPM4", "PM1xPM2xPM3", "PM1xPM2xPM3xPM4", "PM1xPM2*xPM3*"]
NOMS_VIEMUON = ["START = PM4 / STOP = PM4",
                "START = PM4xPM1 / STOP = PM4 x PM1* x PM2*"]

# --- Constantes de conversion (valeurs lues dans les VI d'origine) ----------
GAIN_AMPLI_ENTREE = 10.0      # seuil après ampli = seuil d'entrée x 10
DAC_MAX_MV = 3300.0           # DAC 12 bits, 3,3 V
DAC_MAX_CODE = 4095
HT_MAX_VOLTS = 1500.0         # consigne 0..1500 V  ->  commande 0..5 V
HT_COMMANDE_MAX = 5.0         # « Limitation 5V »
HT_DAC_PLEINE_ECHELLE = 6.6   # « Valeur tension maximum »
ADC_MAX_VOLTS = 3.3           # ADC 12 bits, 3,3 V
ADC_BITS = 12
HT_FACTEUR_LECTURE = 485      # HT (V) = tension ADC x 485
HORLOGE_NS = 8                # « Horloge KA2 en ns »

TIMEOUT_S = 3.0               # « Timeout sur message » : 3000 ms


class ErreurBoitier(Exception):
    pass


def code_seuil(seuil_mv):
    code = round(seuil_mv * GAIN_AMPLI_ENTREE / DAC_MAX_MV * DAC_MAX_CODE)
    return max(0, min(DAC_MAX_CODE, int(code)))


def code_ht(volts):
    commande = max(0.0, volts) * HT_COMMANDE_MAX / HT_MAX_VOLTS
    commande = min(commande, HT_COMMANDE_MAX)
    code = round(commande / HT_DAC_PLEINE_ECHELLE * DAC_MAX_CODE)
    return max(0, min(DAC_MAX_CODE, int(code)))


def volts_depuis_adc_ht(code):
    return code * ADC_MAX_VOLTS / (2 ** ADC_BITS) * HT_FACTEUR_LECTURE


def trame(commande, data1=0, data2=0, data3=0):
    return bytes([0x23, commande & 0xFF, data1 & 0xFF, data2 & 0xFF, data3 & 0xFF, 0x3F])


class Boitier:
    """Pilote du boîtier. `port` est un objet de type serial.Serial (ou le simulateur)."""

    def __init__(self, port, journal=None):
        self.port = port
        self.journal = journal or (lambda texte: None)
        self.verrou = threading.Lock()

    @classmethod
    def ouvrir(cls, nom_port, journal=None, dtr=True, rts=True, attente=0.2):
        """Ouvre le port à 9600 bauds 8N1. dtr / rts : état des lignes de contrôle à l'ouverture."""
        import serial  # pyserial
        port = serial.Serial()
        port.port = nom_port
        port.baudrate, port.bytesize, port.parity, port.stopbits = 9600, 8, "N", 1
        port.xonxoff = port.rtscts = port.dsrdtr = False
        port.timeout, port.write_timeout = 0.1, TIMEOUT_S   # lectures courtes, délai géré par echange
        port.dtr, port.rts = dtr, rts                         # appliqués dès l'ouverture
        port.open()
        time.sleep(attente)
        port.reset_input_buffer()
        return cls(port, journal)

    def fermer(self):
        try:
            self.port.close()
        except Exception:
            pass

    # -- échange élémentaire --------------------------------------------------
    def _purger(self, pause=0.3):
        """Attend la fin d'une éventuelle réponse en retard et vide le tampon de réception."""
        time.sleep(pause)
        try:
            n = self.port.in_waiting
            restes = self.port.read(n) if n else b""
            self.port.reset_input_buffer()
        except Exception:
            restes = b""
        if restes:
            self.journal(f"octets en trop jetés : {restes.hex(' ')}")

    def _echange_brut(self, message, timeout=None):
        """Envoie une trame et renvoie ce qui a été reçu (6 octets attendus), sans contrôle."""
        en_attente = self.port.in_waiting
        if en_attente:
            restes = self.port.read(en_attente)
            self.journal(f"attention : {len(restes)} octets en attente avant l'envoi ({restes.hex(' ')})")
        self.port.write(message)
        reponse = b""
        limite = time.monotonic() + (timeout or TIMEOUT_S)
        while len(reponse) < 6 and time.monotonic() < limite:
            morceau = self.port.read(6 - len(reponse))
            if morceau:
                reponse += morceau
        self.journal(f"-> {message.hex(' ')}   <- {reponse.hex(' ') if reponse else '(rien)'}")
        return reponse

    @staticmethod
    def _reponse_valide(reponse):
        return len(reponse) == 6 and reponse[0] == 0x23 and reponse[5] == 0x3F

    def echange(self, commande, data1=0, data2=0, data3=0, essais=3):
        message = trame(commande, data1, data2, data3)
        with self.verrou:
            for essai in range(1, essais + 1):
                reponse = self._echange_brut(message)
                if self._reponse_valide(reponse):
                    return reponse
                recu = reponse.hex(' ') if reponse else "rien"
                self.journal(f"réponse incorrecte ({len(reponse)} octets : {recu}), essai {essai}/{essais}")
                self._purger()
        raise ErreurBoitier(f"réponse incorrecte : {len(reponse)} octets reçus au lieu de 6 ({recu})")

    def synchroniser(self, decalages=6):
        """Remet en phase l'échange avec le boîtier.

        Si le boîtier a gardé des octets d'une trame incomplète (parasite à l'ouverture du
        port, câble débranché pendant un échange…), toutes les trames suivantes sont
        décalées. On envoie une lecture sans effet (lecture HT voie 1) ; si la réponse est
        mauvaise, on envoie un octet nul pour décaler d'un cran, et on recommence.
        Les trames ainsi formées ne contiennent que les octets 23, 08, 00 et 3F :
        elles ne peuvent pas programmer une haute tension.
        """
        message = trame(CMD_LIRE_HT, 0)
        with self.verrou:
            self._purger(0.1)
            for decalage in range(decalages + 1):
                reponse = self._echange_brut(message, timeout=0.6)
                if self._reponse_valide(reponse):
                    if decalage:
                        self.journal(f"échange resynchronisé après {decalage} octet(s) de décalage")
                    return True
                self._purger(0.2)
                self.port.write(b"\x00")
                self._purger(0.2)
        return False

    def _lire_valeur(self, commande, index):
        r = self.echange(commande, index)
        return r[3] * 256 + r[4]

    # -- commandes de haut niveau --------------------------------------------
    def programmer_seuil(self, voie, seuil_mv):
        code = code_seuil(seuil_mv)
        self.echange(CMD_SEUIL, voie, (code & 0xF00) >> 8, code & 0xFF)
        return code

    def programmer_ht(self, voie, volts):
        code = code_ht(volts)
        self.echange(CMD_ECRIRE_HT, voie, (code & 0xF00) >> 8, code & 0xFF)
        return code

    def lire_ht(self, voie):
        return volts_depuis_adc_ht(self._lire_valeur(CMD_LIRE_HT, voie))

    def lire_voie(self, voie):
        return self._lire_valeur(CMD_LIRE_VOIE, voie)

    def lire_fonction(self, fonction):
        return self._lire_valeur(CMD_LIRE_FONCTION, fonction)

    def lire_viemuon_brut(self, index):
        return self._lire_valeur(CMD_LIRE_VIEMUON, index)

    def raz_voie(self, voie):
        self.echange(CMD_RAZ_VOIE, voie)

    def raz_fonction(self, fonction):
        self.echange(CMD_RAZ_FONCTION, fonction)

    def raz_viemuon(self, index):
        self.echange(CMD_RAZ_VIEMUON, index)

    def raz_tout(self):
        for v in range(4):
            self.raz_voie(v)
        for f in range(9):
            self.raz_fonction(f)
        for m in range(2):
            self.raz_viemuon(m)


# =============================================================================
#  Simulateur : un faux boîtier qui répond au même protocole, pour essayer le
#  logiciel sans le détecteur (option « Simulation » de l'interface).
# =============================================================================

def _poisson(lam):
    if lam <= 0:
        return 0
    if lam > 30:
        return max(0, int(round(random.gauss(lam, math.sqrt(lam)))))
    l, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= random.random()
        if p <= l:
            return k
        k += 1


def _sigmoide(x):
    return 1.0 / (1.0 + math.exp(-x))


class BoitierSimule:
    """Imite l'interface de serial.Serial (write / read / in_waiting / close).

    Modèle calé sur les mesures du lycée Charles de Gaulle (Caen) :
    étalonnage HT des PM1, PM2, PM3 (déc. 2023), balayage en seuil à 1000 V (janv. 2024),
    comptage de 72 h à 900 V / 16 mV (mars 2025), vies du muon (2023 et 2025).
    """

    # Raquettes de haut en bas (index 0 = PM1) : PM3 au milieu, comme en mars 2025.
    ORDRE = (0, 2, 1)
    # Flux géométriques (muons/s, détecteurs parfaits) : à travers les 3 raquettes,
    # ou seulement à travers deux raquettes voisines.
    FLUX_TROIS = 1.75
    FLUX_VOISINES = 1.30
    # Comptages simples à 1000 V et 20 mV (coups/s) ; loi S = A (s/20)^-0.8 (HT/1000)^6.4
    A_SIMPLES = (31.1, 28.5, 31.8, 30.0)
    # Efficacité de détection des muons : plateau, demi-hauteur (V)
    EFF_MAX = (0.99, 0.97, 0.88, 0.95)
    EFF_H50 = (805, 815, 790, 800)
    # Vie du muon (PM4 à 1000 V / 20 mV, février 2023) : 0,376 événement/s dont
    POSTIMPULSIONS = 0.318      # ~300 ns
    DESINTEGRATIONS = 0.084     # exponentielle
    TAU_MUON_NS = 1950.0        # durée de vie mesurée (µ+ et µ- mélangés)
    FENETRE_NS = 65528          # au-delà, le boîtier ne mesure plus

    def __init__(self, acceleration=1.0):
        # acceleration > 1 : le temps simulé s'écoule plus vite (essais des longues procédures)
        self.acceleration = float(acceleration)
        self.seuil_code = [0] * 4
        self.ht_code = [0] * 4
        self.ht_reelle = [0.0] * 4
        self.voies = [0] * 4
        self.fonctions = [0] * 9
        self.viemuon = [0, 0]
        self.dernier = time.monotonic()
        self._sortie = b""
        self.is_open = True

    # -- modèle ----------------------------------------------------------------
    def _seuil_mv(self, i):
        return max(1.0, self.seuil_code[i] / DAC_MAX_CODE * DAC_MAX_MV / GAIN_AMPLI_ENTREE)

    def _gain(self, i):
        return max(self.ht_reelle[i], 1.0) / 1000.0

    # Comptage simple relatif à celui de 20 mV, mesuré à 1000 V (janvier 2024)
    COURBE_SEUIL = ((2, 4.66), (4, 3.15), (6, 2.47), (8, 2.14), (10, 1.73), (12, 1.55), (14, 1.36),
                    (16, 1.30), (18, 1.13), (20, 1.0), (25, 0.90), (30, 0.71), (40, 0.51), (50, 0.41))
    VETO_PM1 = 0.905   # part des coups isolés de PM1 comptés dans PM1xPM2*xPM3* (mesuré)

    def _facteur_seuil(self, s):
        c = self.COURBE_SEUIL
        if s <= c[0][0]:
            return c[0][1] * (s / c[0][0]) ** -0.55
        if s >= c[-1][0]:
            return c[-1][1] * (s / c[-1][0]) ** -0.9
        for (s0, f0), (s1, f1) in zip(c, c[1:]):
            if s0 <= s <= s1:   # interpolation en échelles logarithmiques
                k = math.log(s / s0) / math.log(s1 / s0)
                return math.exp(math.log(f0) + k * (math.log(f1) - math.log(f0)))

    def _simples(self, i):
        ht = self.ht_reelle[i]
        if ht < 300:
            return 0.0
        return (self.A_SIMPLES[i] * self._facteur_seuil(self._seuil_mv(i)) * self._gain(i) ** 6.4
                * _sigmoide((ht - 780) / 40))

    def _efficacite(self, i):
        return (self.EFF_MAX[i] * _sigmoide((self.ht_reelle[i] - self.EFF_H50[i]) / 20)
                * _sigmoide((150 - self._seuil_mv(i)) / 30))

    def _exces_bas_seuil(self, a, b, amplitude, echelle):
        """Coïncidences supplémentaires vues à très bas seuil (particules peu ionisantes)."""
        s = max(self._seuil_mv(a) / self._gain(a) ** 8, self._seuil_mv(b) / self._gain(b) ** 8)
        return amplitude * math.exp(-s / echelle) * min(self._efficacite(a), self._efficacite(b))

    def taux_attendus(self):
        """Classes d'événements corrélés : (ensemble de PM touchés, taux en /s)."""
        h, m, b = self.ORDRE
        return [((h, m, b), self.FLUX_TROIS), ((h, m), self.FLUX_VOISINES), ((m, b), self.FLUX_VOISINES)]

    def _avancer(self, dt=None):
        maintenant = time.monotonic()
        if dt is None:
            dt = (maintenant - self.dernier) * self.acceleration
        self.dernier = maintenant
        if dt <= 0:
            return
        for i in range(4):  # la HT rejoint la consigne à ~200 V/s
            cible = min(self.ht_code[i] / DAC_MAX_CODE * HT_DAC_PLEINE_ECHELLE, HT_COMMANDE_MAX) \
                * HT_MAX_VOLTS / HT_COMMANDE_MAX
            pas = 200 * dt
            self.ht_reelle[i] += max(-pas, min(pas, cible - self.ht_reelle[i]))
        eff = [self._efficacite(i) for i in range(4)]
        vus_muons = [0.0] * 4          # taux de comptage simple déjà dû aux événements corrélés

        # muons traversant plusieurs raquettes
        for touches, taux in self.taux_attendus():
            for i in touches:
                vus_muons[i] += taux * eff[i]
            for _ in range(_poisson(taux * dt)):
                self._compter({i for i in touches if random.random() < eff[i]})
        # excès de coïncidences à très bas seuil
        h, m, b = self.ORDRE
        for (a, c), amp, ech in (((h, m), 3.6, 3.2), ((m, b), 3.6, 3.2), ((h, b), 1.2, 4.0)):
            taux = self._exces_bas_seuil(a, c, amp, ech)
            vus_muons[a] += taux
            vus_muons[c] += taux
            for _ in range(_poisson(taux * dt)):
                self._compter({a, c})
        # reste des comptages simples : bruit, radioactivité, muons ne touchant qu'une raquette
        for i in range(4):
            n = _poisson(max(0.0, self._simples(i) - vus_muons[i]) * dt)
            self.voies[i] = (self.voies[i] + n) & 0xFFFF
            if i == 0:
                n_isoles = sum(random.random() < self.VETO_PM1 for _ in range(n)) if n < 500 \
                    else round(n * self.VETO_PM1)
                self.fonctions[8] = (self.fonctions[8] + n_isoles) & 0xFFFF

        # vie du muon (START = STOP = PM4)
        if self.ht_reelle[3] > 300:
            reference = self.EFF_MAX[3] * _sigmoide(200 / 20) * _sigmoide(130 / 30)
            taux = 0.376 * eff[3] / reference
            for _ in range(_poisson(taux * dt)):
                u = random.random()
                if u < self.POSTIMPULSIONS:
                    v = random.random()
                    if v < 0.82:
                        t = random.gauss(300, 25)            # post-impulsions rapides
                    elif v < 0.85:
                        t = random.gauss(1450, 220)          # post-impulsions tardives (~1,5 µs)
                    else:
                        t = random.uniform(0, 1000)
                elif u < self.POSTIMPULSIONS + self.DESINTEGRATIONS:
                    t = random.expovariate(1 / self.TAU_MUON_NS)
                else:
                    t = random.uniform(0, self.FENETRE_NS)      # START et STOP sans lien (fond plat)
                ticks = int(max(0, t) / HORLOGE_NS)
                if 0 < ticks <= self.FENETRE_NS // HORLOGE_NS and self.viemuon[0] == 0:
                    self.viemuon[0] = ticks

    def _compter(self, vus):
        for i in vus:
            self.voies[i] = (self.voies[i] + 1) & 0xFFFF
        paires = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
        for k, (a, b) in enumerate(paires):
            if a in vus and b in vus:
                self.fonctions[k] = (self.fonctions[k] + 1) & 0xFFFF
        if {0, 1, 2} <= vus:
            self.fonctions[6] = (self.fonctions[6] + 1) & 0xFFFF
        if {0, 1, 2, 3} <= vus:
            self.fonctions[7] = (self.fonctions[7] + 1) & 0xFFFF
        if 0 in vus and 1 not in vus and 2 not in vus and random.random() < self.VETO_PM1:
            self.fonctions[8] = (self.fonctions[8] + 1) & 0xFFFF

    # -- interface « port série » --------------------------------------------
    @property
    def in_waiting(self):
        return len(self._sortie)

    def reset_input_buffer(self):
        self._sortie = b""

    def write(self, donnees):
        time.sleep(0.0125 / self.acceleration)  # durée d'un échange réel à 9600 bauds
        if len(donnees) != 6 or donnees[0] != 0x23 or donnees[5] != 0x3F:
            return len(donnees)
        self._avancer()
        cmd, d1, d2, d3 = donnees[1], donnees[2], donnees[3], donnees[4]
        valeur = None
        if cmd == CMD_SEUIL and d1 < 4:
            self.seuil_code[d1] = (d2 << 8) | d3
        elif cmd == CMD_ECRIRE_HT and d1 < 4:
            self.ht_code[d1] = (d2 << 8) | d3
        elif cmd == CMD_LIRE_VOIE and d1 < 4:
            valeur = self.voies[d1]
        elif cmd == CMD_RAZ_VOIE and d1 < 4:
            self.voies[d1] = 0
        elif cmd == CMD_LIRE_FONCTION and d1 < 9:
            valeur = self.fonctions[d1]
        elif cmd == CMD_RAZ_FONCTION and d1 < 9:
            self.fonctions[d1] = 0
        elif cmd == CMD_LIRE_VIEMUON and d1 < 2:
            valeur = self.viemuon[d1]
        elif cmd == CMD_RAZ_VIEMUON and d1 < 2:
            self.viemuon[d1] = 0
        elif cmd == CMD_LIRE_HT and d1 < 4:
            v = self.ht_reelle[d1] / HT_FACTEUR_LECTURE / ADC_MAX_VOLTS * 2 ** ADC_BITS
            valeur = max(0, min(4095, int(v + random.uniform(0, 12))))
        if valeur is not None:
            d2, d3 = (valeur >> 8) & 0xFF, valeur & 0xFF
        self._sortie += bytes([0x23, cmd, d1, d2, d3, 0x3F])
        return 6

    def read(self, n=1):
        donnees, self._sortie = self._sortie[:n], self._sortie[n:]
        return donnees

    def close(self):
        self.is_open = False
