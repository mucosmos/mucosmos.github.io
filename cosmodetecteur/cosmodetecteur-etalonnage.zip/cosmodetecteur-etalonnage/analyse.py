# Cosmodétecteur-étalonnage — interface Python-web
# Conception et direction du projet : Cédric Vanden Driessche (2026), professeur de
# physique-chimie au lycée Charles de Gaulle à Caen (cedric.vanden-driessche@ac-normandie.fr) ;
# développement du code : Claude (Anthropic), sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
# Ce programme est un logiciel libre, distribué selon les termes de la GNU GPL version 3
# ou ultérieure, SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Analyse des trois étalonnages (fonctions sans effet de bord, testables séparément).

* Haute tension (livret, § 2.2) : rapport R = N(coïncidence avec le PM étudié) / N(coïncidence
  des deux PM de référence) en fonction de la HT, ajusté par une courbe en S
  R = P / (1 + exp(-(V - V50) / w)). P est le plateau ; le « coude » est la tension où R atteint
  95 % du plateau. Tension conseillée : coude + marge (50 V par défaut), comme « régler la
  tension du PM au-delà de 950 V ».
* Seuils (livret, § 3.1) : nombre de coïncidences en fonction du seuil. Le plateau est la plus
  longue suite de points compatibles avec une constante (test du χ²) ; seuil conseillé : milieu
  du plateau (ou début du plateau + 2 points si le plateau continue jusqu'au dernier seuil).
* Temps mort (livret, § 2.3) : pour chaque intervalle Δt, on compte pendant une durée totale D
  découpée en n intervalles. Chaque lecture + remise à zéro fait perdre un temps τ :
  N = R × (D − n τ). Ajustement linéaire pondéré (poids 1/N) de N = R D + c n, puis τ = −c / R.
"""

import math

HT_LIMITE = 1350.0          # « NE PAS DÉPASSER 1350 V POUR NE PAS DÉGRADER LE PM »


def _fr(x, d=2):
    return f"{x:.{d}f}".replace(".", ",")


def _moyenne_ponderee(valeurs, erreurs):
    poids = [1.0 / max(e, 1e-9) ** 2 for e in erreurs]
    total = sum(poids)
    m = sum(p * v for p, v in zip(poids, valeurs)) / total
    return m, math.sqrt(1.0 / total)


# ------------------------------------------------------------------ hautes tensions
def rapport(n_coinc, n_ref):
    """Rapport et incertitude (loi binomiale)."""
    if n_ref <= 0:
        return None, None
    r = n_coinc / n_ref
    err = math.sqrt(max(r * (1 - r), 0.0) / n_ref) if r < 1 else 1.0 / n_ref
    return r, max(err, 1.0 / n_ref)


def ajuster_sigmoide(v, r, e):
    """Ajuste r(V) = P / (1 + exp(-(V - V50) / w)) par moindres carrés pondérés.

    Pour V50 et w fixés, le meilleur P se calcule directement ; on cherche V50 et w sur une grille
    (grossière puis fine). Renvoie (P, V50, w, chi2).
    """
    poids = [1.0 / max(x, 1e-6) ** 2 for x in e]

    def evaluer(v50, w):
        f = [1.0 / (1.0 + math.exp(max(-60.0, min(60.0, -(vi - v50) / w)))) for vi in v]
        sff = sum(p * fi * fi for p, fi in zip(poids, f))
        if sff <= 0:
            return None
        P = sum(p * fi * ri for p, fi, ri in zip(poids, f, r)) / sff
        chi2 = sum(p * (ri - P * fi) ** 2 for p, fi, ri in zip(poids, f, r))
        return chi2, P

    meilleur = None
    for pas_v, pas_w, centre in ((10.0, 4.0, None), (1.0, 0.5, True)):
        if centre is None:
            v50s = [min(v) - 200 + pas_v * i for i in range(int((max(v) - min(v) + 300) / pas_v) + 1)]
            ws = [3.0 + pas_w * i for i in range(50)]
        else:
            _, _, v0, w0 = meilleur
            v50s = [v0 - 12 + pas_v * i for i in range(25)]
            ws = [max(1.0, w0 - 5 + pas_w * i) for i in range(21)]
        for v50 in v50s:
            for w in ws:
                res = evaluer(v50, w)
                if res and (meilleur is None or res[0] < meilleur[0]):
                    meilleur = (res[0], res[1], v50, w)
    chi2, P, v50, w = meilleur
    return P, v50, w, chi2


def analyser_ht(points, marge=50.0, v_max=HT_LIMITE):
    """points : liste de dict {v, n_coinc, n_ref}. Renvoie un dict de résultats.

    Le coude est la tension où la courbe ajustée atteint 95 % du plateau : V50 + w ln 19.
    """
    res = {"ok": False, "avertissements": []}
    valides = []
    for p in sorted(points, key=lambda p: p["v"]):
        r, e = rapport(p["n_coinc"], p["n_ref"])
        if r is not None and p["n_ref"] >= 10:
            valides.append((p["v"], r, e))
    if len(valides) < 4:
        res["message"] = "Pas encore assez de points."
        return res
    v = [x[0] for x in valides]
    r = [x[1] for x in valides]
    e = [x[2] for x in valides]
    if max(r) <= 0:
        res["message"] = "Aucune coïncidence : vérifiez les PM de référence."
        return res
    plateau, v50, w, chi2 = ajuster_sigmoide(v, r, e)
    coude = v50 + w * math.log(19.0)
    if coude < v[0]:
        res["avertissements"].append("Le rapport est déjà sur le plateau au début de la plage : "
                                     "le coude est peut-être plus bas que la plage étudiée.")
        coude = v[0]
    apres = [i for i in range(len(v)) if v[i] > coude]
    if len(apres) < 2:
        res["avertissements"].append("Peu de points après le coude : prolongez la plage vers les hautes "
                                     f"tensions (sans dépasser {HT_LIMITE:.0f} V) pour confirmer le plateau.")
    if coude > v[-1]:
        res["message"] = "Le plateau n'est pas atteint dans la plage étudiée."
        return res
    conseil = math.ceil((coude + marge) / 10.0) * 10.0
    conseil = min(conseil, v_max, HT_LIMITE)
    res.update({"ok": True, "plateau": plateau, "coude": coude, "v50": v50, "largeur": w,
                "chi2": chi2, "ndf": len(v) - 3, "conseil": conseil, "niveau": 0.95 * plateau,
                "message": f"Plateau à {_fr(plateau)} ; coude (95 % du plateau) vers {coude:.0f} V ; "
                           f"tension conseillée {conseil:.0f} V."})
    return res


# ----------------------------------------------------------------------- seuils
def analyser_seuils(points, cle):
    """points : liste de dict {s, duree, comptes{cle: N}}. Taux ramenés à 5 minutes."""
    res = {"ok": False, "avertissements": []}
    pts = sorted([p for p in points if p["duree"] > 0], key=lambda p: p["s"])
    if len(pts) < 4:
        res["message"] = "Pas encore assez de points."
        return res
    s = [p["s"] for p in pts]
    n = [p["comptes"][cle] for p in pts]
    f = [300.0 / p["duree"] for p in pts]
    y = [ni * fi for ni, fi in zip(n, f)]
    ey = [math.sqrt(max(ni, 1)) * fi for ni, fi in zip(n, f)]
    if max(n) < 20:
        res["message"] = "Trop peu de coïncidences pour trouver le plateau (HT trop basses ?)."
        return res

    def compatible(i, j):
        m, _ = _moyenne_ponderee(y[i:j + 1], ey[i:j + 1])
        chi2 = sum(((y[k] - m) / ey[k]) ** 2 for k in range(i, j + 1))
        ndf = j - i
        return chi2 / ndf <= 1 + 2 * math.sqrt(2.0 / ndf), m

    meilleur = None
    for i in range(len(s)):
        for j in range(i + 2, len(s)):
            ok, m = compatible(i, j)
            if not ok:
                break
            longueur = j - i
            if meilleur is None or longueur > meilleur[1] - meilleur[0]:
                meilleur = (i, j, m)
    if not meilleur:
        res["message"] = "Pas de plateau net : refaites la mesure avec une durée plus longue par point."
        return res
    i, j, m = meilleur
    if j < len(s) - 1:
        milieu = (s[i] + s[j]) / 2
        conseil = min(s[i:j + 1], key=lambda x: (abs(x - milieu), x))
        pourquoi = "milieu du plateau"
    else:
        # le plateau continue au-delà du dernier seuil : son milieu n'est pas connu ;
        # on se place un peu après son début, à l'écart de la remontée due au bruit
        conseil = s[min(i + 2, j)]
        pourquoi = "début du plateau + 2 points, car le plateau continue au-delà du dernier seuil mesuré"
    if i == 0:
        res["avertissements"].append("Le plateau commence dès le premier seuil : commencez plus bas pour voir "
                                     "le bruit de fond.")
    res.update({"ok": True, "debut": s[i], "fin": s[j], "niveau": m, "conseil": conseil,
                "message": f"Plateau de {s[i]:g} à {s[j]:g} mV (≈ {m:.0f} coïncidences en 5 min) ; "
                           f"seuil conseillé {conseil:g} mV ({pourquoi})."})
    return res


# -------------------------------------------------------------------- temps mort
def analyser_temps_mort(points):
    """points : liste de dict {dt, n, duree, N}. Ajuste N = R·duree − R·τ·n."""
    res = {"ok": False, "avertissements": []}
    pts = [p for p in points if p["N"] > 0 and p["n"] > 0]
    if len({p["dt"] for p in pts}) < 2:
        res["message"] = "Il faut au moins deux intervalles différents."
        return res
    # moindres carrés pondérés, inconnues (R, c) avec N = R D + c n, poids 1/N
    sDD = sDn = snn = sND = sNn = 0.0
    for p in pts:
        w = 1.0 / p["N"]
        D, n, N = p["duree"], p["n"], p["N"]
        sDD += w * D * D; sDn += w * D * n; snn += w * n * n
        sND += w * N * D; sNn += w * N * n
    det = sDD * snn - sDn * sDn
    if abs(det) < 1e-12:
        res["message"] = "Points trop semblables pour l'ajustement."
        return res
    R = (sND * snn - sNn * sDn) / det
    c = (sDD * sNn - sDn * sND) / det
    vR, vc, cov = snn / det, sDD / det, -sDn / det
    if R <= 0:
        res["message"] = "Ajustement impossible (taux nul)."
        return res
    tau = -c / R
    var_tau = vc / R ** 2 + c ** 2 * vR / R ** 4 - 2 * c * cov / R ** 3
    err_tau = math.sqrt(max(var_tau, 0.0))
    chi2 = sum((p["N"] - (R * p["duree"] + c * p["n"])) ** 2 / p["N"] for p in pts)
    ndf = len(pts) - 2
    compatible_zero = abs(tau) < 2 * err_tau
    res.update({"ok": True, "taux": R, "err_taux": math.sqrt(vR), "tau": tau, "err_tau": err_tau,
                "chi2": chi2, "ndf": ndf, "compatible_zero": compatible_zero})
    if compatible_zero:
        res["message"] = (f"τ = {_fr(tau)} ± {_fr(err_tau)} s : compatible avec zéro. Le temps mort est trop petit "
                          "pour être vu avec ces comptages.")
    else:
        res["message"] = f"Temps mort τ = {_fr(tau)} ± {_fr(err_tau)} s."
    return res
