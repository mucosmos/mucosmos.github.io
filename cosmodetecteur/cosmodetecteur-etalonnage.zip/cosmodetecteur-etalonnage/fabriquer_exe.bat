@echo off
rem Fabrique Cosmodetecteur-etalonnage.exe pour Windows avec PyInstaller.
rem A lancer une seule fois, sur un PC Windows avec Python et une connexion internet.
chcp 65001 >nul
cd /d "%~dp0"
set PY=py
where py >nul 2>nul || set PY=python
%PY% --version >nul 2>nul || goto :sanspython
echo Installation des outils (PyInstaller, pyserial)...
%PY% -m pip install --upgrade pyinstaller pyserial || goto :erreur
echo.
echo Fabrication de Cosmodetecteur-etalonnage.exe (1 a 2 minutes)...
%PY% -m PyInstaller --noconfirm --clean --onefile --name Cosmodetecteur-etalonnage --icon cosmodetecteur-etalonnage.ico --add-data "web;web" cosmodetecteur_etalonnage.py || goto :erreur
echo.
echo Termine : le logiciel est le fichier  dist\Cosmodetecteur-etalonnage.exe
echo Copiez-le ou vous voulez (cle USB, bureau...). Ses mesures seront rangees
echo dans un dossier "mesures" cree a cote de lui.
explorer dist
pause
exit /b
:sanspython
echo Python n'est pas installe sur cet ordinateur.
echo Installez-le depuis https://www.python.org/downloads/ en cochant "Add python.exe to PATH".
pause
exit /b
:erreur
echo.
echo La fabrication a echoue : verifiez la connexion internet et lisez le message ci-dessus.
pause
