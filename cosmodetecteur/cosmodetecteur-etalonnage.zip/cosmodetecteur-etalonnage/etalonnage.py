# Cosmodétecteur-étalonnage — interface Python-web
# Logiciel compagnon du programme « Cosmodétecteur » (adaptation du logiciel Roue Cosmique
# [Sciences à l'École, CPPM] [Michel Jevaud, Marta Rodo Bordera, 2011] pour le Cosmodétecteur
# [José Busto]) ; conception et direction du projet : Cédric Vanden Driessche (2026), professeur
# de physique-chimie au lycée Charles de Gaulle à Caen (cedric.vanden-driessche@ac-normandie.fr) ;
# développement du code : Claude (Anthropic), sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
# Ce programme est un logiciel libre, distribué selon les termes de la GNU GPL version 3
# ou ultérieure, SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Déroulement automatique des étalonnages du cosmodétecteur :

1. hautes tensions des PM (livret pédagogique, § 2.2) ;
2. seuils de discrimination (§ 3.1) ;
3. temps mort de l'acquisition (§ 2.3).

Un seul fil d'exécution parle au boîtier. Hors étalonnage, il lit les compteurs et les HT
pour l'affichage ; pendant un étalonnage, il exécute le programme pas à pas.
"""

import collections
import datetime
import math
import os
import queue
import threading
import time
import traceback

import analyse
from analyse import HT_LIMITE
from boitier import Boitier, BoitierSimule, ErreurBoitier, NOMS_FONCTIONS, NOMS_VOIES

JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]
SEUIL_CONNEXION_MV = 40.0
CLES = [f"v{i}" for i in range(4)] + [f"f{i}" for i in range(9)]
NOMS_CLES = {**{f"v{i}": n for i, n in enumerate(NOMS_VOIES)},
             **{f"f{i}": n.replace("x", "×") for i, n in enumerate(NOMS_FONCTIONS)}}
PAIRE = {(0, 1): 0, (0, 2): 1, (1, 2): 3}          # fonction de coïncidence de deux PM
STABILISATION_S = 3.0                             # attente après que la HT a rejoint la consigne
ECART_HT_V = 20.0


class Erreur(Exception):
    """Erreur à afficher telle quelle à l'utilisateur."""


class Interruption(Exception):
    pass


_CP1252 = str.maketrans({"τ": "tau", "≈": "~", "→": "->", "−": "-", "Δ": "d"})


def _texte_fichier(t):
    """Caractères absents de l'encodage Windows (cp1252) des fichiers de mesure."""
    return t.translate(_CP1252)


def _fr(x, d=2):
    return f"{x:.{d}f}".replace(".", ",")


def _liste(valeurs, mini, maxi, nom, unite):
    try:
        l = sorted({float(v) for v in valeurs})
    except (TypeError, ValueError):
        raise Erreur(f"{nom} : valeurs invalides.")
    if not l:
        raise Erreur(f"{nom} : aucune valeur.")
    if l[0] < mini or l[-1] > maxi:
        raise Erreur(f"{nom} : les valeurs doivent être comprises entre {mini:g} et {maxi:g} {unite}.")
    return l


class Station:
    def __init__(self, dossier):
        self.dossier = dossier
        os.makedirs(dossier, exist_ok=True)
        self.verrou = threading.RLock()
        self.commandes = queue.Queue()
        self.journal_lignes = collections.deque(maxlen=500)
        self.boitier = None
        self.fil = None
        self.arret = threading.Event()        # arrêt du fil (déconnexion)
        self.stop = threading.Event()         # arrêt du programme d'étalonnage
        self.programme_demande = None
        self.resultats = {"ht": {}, "seuils": None, "temps_mort": None}
        self.reglages = {"ht": [None] * 4, "seuil": None, "tau": None}
        self._reinitialiser()

    def _reinitialiser(self):
        self.connecte = False
        self.port = None
        self.simulation = False
        self.k = 1.0                          # accélération du temps (simulation seulement)
        self.message = ""
        self.ht_consigne = [0.0] * 4
        self.ht_mesure = [0.0] * 4
        self.seuils = [SEUIL_CONNEXION_MV] * 4
        self.compteurs = [0] * 13
        self.prog = None

    def journal(self, texte):
        if texte.startswith("->"):
            return
        self.journal_lignes.append(f"{datetime.datetime.now():%H:%M:%S}  {texte}")

    # ------------------------------------------------------------------ état
    def etat(self):
        with self.verrou:
            prog = None
            if self.prog:
                prog = dict(self.prog)
                restant = prog.pop("restant_sim", 0)
                prog["restant_reel"] = restant / self.k
            return {"connecte": self.connecte, "port": self.port, "simulation": self.simulation,
                    "acceleration": self.k, "message": self.message, "heure": time.time(),
                    "ht_consigne": self.ht_consigne, "ht_mesure": [round(v, 1) for v in self.ht_mesure],
                    "seuils": self.seuils, "compteurs": self.compteurs, "noms_cles": NOMS_CLES,
                    "cles": CLES, "programme": prog, "resultats": self.resultats,
                    "reglages": self.reglages, "ht_limite": HT_LIMITE}

    # ------------------------------------------------------------- connexion
    def connecter(self, port, simulation=False, accelere=False):
        self.deconnecter()
        if simulation:
            k = 60.0 if accelere else 1.0
            boitier, nom = Boitier(BoitierSimule(acceleration=k), self.journal), "simulation"
        else:
            k = 1.0
            if not port:
                raise Erreur("Choisissez un port série.")
            try:
                boitier = Boitier.ouvrir(port, self.journal)
            except Exception as e:
                if "ermission" in str(e):
                    raise Erreur(f"Accès refusé au port {port}. Débranchez puis rebranchez le câble, "
                                 "ou fermez l'autre logiciel du cosmodétecteur s'il est connecté.")
                raise Erreur(f"Impossible d'ouvrir {port} : {e}")
            nom = port
            if not boitier.synchroniser():
                ok = False
                for dtr, rts in [(True, True), (False, False), (True, False), (False, True)]:
                    boitier.fermer()
                    time.sleep(1.0)
                    try:
                        boitier = Boitier.ouvrir(port, self.journal, dtr=dtr, rts=rts, attente=2.0)
                    except Exception as e:
                        raise Erreur(f"Impossible de rouvrir {port} : {e}")
                    if boitier.synchroniser(decalages=2):
                        ok = True
                        break
                if not ok:
                    boitier.fermer()
                    raise Erreur(f"Le boîtier ne répond pas correctement sur {nom}. Éteignez puis rallumez le "
                                 "boîtier, attendez quelques secondes et cliquez de nouveau sur « Connecter ».")
        try:
            for v in range(4):
                boitier.programmer_seuil(v, SEUIL_CONNEXION_MV)
                boitier.programmer_ht(v, 0)
            boitier.raz_tout()
        except ErreurBoitier as e:
            boitier.fermer()
            raise Erreur(f"Le boîtier ne répond pas sur {nom} ({e}).")
        with self.verrou:
            self._reinitialiser()
            self.boitier, self.connecte, self.port = boitier, True, nom
            self.simulation, self.k = simulation, k
        self.journal(f"Connexion à {nom}" + (" (simulation accélérée × 60)" if k > 1 else "")
                     + f" : HT à 0 V, seuils à {SEUIL_CONNEXION_MV:g} mV")
        self.arret.clear()
        self.fil = threading.Thread(target=self._boucle, daemon=True)
        self.fil.start()

    def deconnecter(self):
        if not self.boitier:
            return
        self.stop.set()
        self.arret.set()
        if self.fil and self.fil is not threading.current_thread():
            self.fil.join(timeout=15)
        try:
            for v in range(4):
                self.boitier.programmer_ht(v, 0)
            self.journal("HT remises à 0 V")
        except Exception as e:
            self.journal(f"Impossible de remettre les HT à 0 : {e}")
        self.boitier.fermer()
        with self.verrou:
            self.boitier = None
            self.connecte = False
            self.prog = None

    # ------------------------------------------------------ commandes (UI)
    def _executer(self, fonction):
        if not self.connecte:
            raise Erreur("Le boîtier n'est pas connecté.")
        if self.prog:
            raise Erreur("Un étalonnage est en cours.")
        fini, resultat = threading.Event(), {}
        self.commandes.put((fonction, fini, resultat))
        if not fini.wait(30):
            raise Erreur("Le boîtier ne répond pas.")
        if "erreur" in resultat:
            raise resultat["erreur"]

    def appliquer(self, ht, seuil):
        """Règle les HT (liste de 4 valeurs, None = inchangée) et le seuil (toutes les voies)."""
        ht = [None if v in (None, "") else float(v) for v in ht]
        for v in ht:
            if v is not None and not 0 <= v <= HT_LIMITE:
                raise Erreur(f"Les HT doivent être comprises entre 0 et {HT_LIMITE:.0f} V.")
        if seuil not in (None, ""):
            seuil = float(seuil)
            if not 0 < seuil <= 330:
                raise Erreur("Le seuil doit être compris entre 0 et 330 mV.")
        else:
            seuil = None

        def action():
            for i, v in enumerate(ht):
                if v is not None:
                    self._regler_ht(i, v)
            if seuil is not None:
                for i in range(4):
                    self._regler_seuil(i, seuil)
        self._executer(action)

    def lancer(self, etapes, couper_ht=True):
        if not self.connecte:
            raise Erreur("Le boîtier n'est pas connecté.")
        if self.prog or self.programme_demande:
            raise Erreur("Un étalonnage est déjà en cours.")
        if not etapes:
            raise Erreur("Choisissez au moins un étalonnage.")
        plan = [self._preparer(e) for e in etapes]
        self.stop.clear()
        self.programme_demande = {"plan": plan, "couper_ht": bool(couper_ht)}

    def arreter(self):
        if self.prog or self.programme_demande:
            self.stop.set()

    # --------------------------------------------------- vérification des paramètres
    def _preparer(self, e):
        quoi = e.get("type")
        duree = float(e.get("duree", 300))
        if duree < 10:
            raise Erreur("La durée de comptage doit être d'au moins 10 s.")
        if quoi == "ht":
            pms = sorted({int(p) for p in e.get("pms", [])})
            if not pms or not set(pms) <= {0, 1, 2, 3}:
                raise Erreur("Hautes tensions : choisissez au moins un PM.")
            pas = float(e.get("pas", 50))
            vmin, vmax = float(e.get("vmin", 800)), float(e.get("vmax", 1300))
            if pas <= 0 or vmin < 300 or vmax > HT_LIMITE or vmax < vmin + 2 * pas:
                raise Erreur(f"Hautes tensions : plage invalide (de 300 à {HT_LIMITE:.0f} V, au moins 3 points).")
            ref = float(e.get("ht_ref", 1200))
            if not 500 <= ref <= HT_LIMITE:
                raise Erreur(f"La HT des PM de référence doit être comprise entre 500 et {HT_LIMITE:.0f} V.")
            n = int(math.floor((vmax - vmin) / pas + 1e-6)) + 1
            tensions = [vmin + i * pas for i in range(n)]
            return {"type": "ht", "pms": pms, "tensions": tensions, "ht_ref": ref, "duree": duree,
                    "seuil": float(e.get("seuil", 12)), "marge": float(e.get("marge", 50)),
                    "points_prevus": len(pms) * n, "duree_prevue": len(pms) * n * (duree + 10)}
        if quoi == "seuils":
            seuils = _liste(e.get("seuils", []), 0.5, 330, "Seuils", "mV")
            if len(seuils) < 4:
                raise Erreur("Seuils : il faut au moins 4 valeurs.")
            ht = self._ht_param(e)
            cle = e.get("cle", "f0")
            if cle not in CLES:
                raise Erreur("Compteur analysé inconnu.")
            return {"type": "seuils", "seuils": seuils, "duree": duree, "ht": ht, "ht_auto": bool(e.get("ht_auto")),
                    "cle": cle, "points_prevus": len(seuils), "duree_prevue": len(seuils) * (duree + 2) + 20}
        if quoi == "temps_mort":
            intervalles = _liste(e.get("intervalles", []), 1, 3600, "Intervalles", "s")
            if len(intervalles) < 2:
                raise Erreur("Temps mort : il faut au moins 2 intervalles différents.")
            if intervalles[-1] > duree:
                raise Erreur("Temps mort : chaque intervalle doit être plus court que la durée de comptage.")
            ajout = float(e.get("ajout", 0))
            if not 0 <= ajout <= 10:
                raise Erreur("Le temps mort ajouté doit être compris entre 0 et 10 s.")
            cle = e.get("cle", "f1")
            if cle not in CLES:
                raise Erreur("Compteur analysé inconnu.")
            seuil = e.get("seuil")
            return {"type": "temps_mort", "intervalles": intervalles, "duree": duree, "ajout": ajout, "cle": cle,
                    "ht": self._ht_param(e), "ht_auto": bool(e.get("ht_auto")),
                    "seuil": float(seuil) if seuil not in (None, "") else 12.0, "seuil_auto": bool(e.get("seuil_auto")),
                    "points_prevus": len(intervalles), "duree_prevue": len(intervalles) * duree + 20}
        raise Erreur("Étalonnage inconnu.")

    @staticmethod
    def _ht_param(e):
        try:
            ht = [float(v or 0) for v in e.get("ht", [1000, 1000, 1000, 0])]
        except (TypeError, ValueError):
            raise Erreur("HT invalides.")
        if len(ht) != 4 or any(not 0 <= v <= HT_LIMITE for v in ht):
            raise Erreur(f"Les HT doivent être comprises entre 0 et {HT_LIMITE:.0f} V.")
        return ht

    # ------------------------------------------------------------ boucle
    def _boucle(self):
        echecs = 0
        while not self.arret.is_set():
            try:
                self._traiter_commandes()
                if self.programme_demande:
                    demande, self.programme_demande = self.programme_demande, None
                    self._executer_programme(demande)
                    continue
                self._lire_etat()
                echecs = 0
            except ErreurBoitier as e:
                echecs += 1
                self.journal(f"Erreur de communication : {e}")
                if echecs >= 3:
                    with self.verrou:
                        self.message = "Le boîtier ne répond plus : vérifiez le câble et l'alimentation, puis reconnectez."
                        self.connecte = False
                    return
                try:
                    self.boitier.synchroniser()
                except Exception:
                    pass
            except Exception:
                self.journal("Erreur interne : " + traceback.format_exc().splitlines()[-1])
            self.arret.wait(0.5)
        self._traiter_commandes()

    def _traiter_commandes(self):
        while True:
            try:
                fonction, fini, resultat = self.commandes.get_nowait()
            except queue.Empty:
                return
            try:
                fonction()
            except ErreurBoitier as e:
                resultat["erreur"] = Erreur(f"Le boîtier ne répond pas : {e}")
            except Exception as e:
                resultat["erreur"] = e
            fini.set()

    def _lire_etat(self):
        b = self.boitier
        valeurs = [b.lire_voie(v) for v in range(4)] + [b.lire_fonction(f) for f in range(9)]
        ht = [b.lire_ht(v) for v in range(4)]
        with self.verrou:
            self.compteurs, self.ht_mesure = valeurs, ht

    # ------------------------------------------------------- outils de mesure
    def _t(self):
        """Temps (en secondes « simulées » : identique au temps réel hors simulation accélérée)."""
        return time.monotonic() * self.k

    def _attendre(self, s):
        if s > 0 and self.stop.wait(s / self.k):
            raise Interruption()
        if self.stop.is_set() or self.arret.is_set():
            raise Interruption()

    def _regler_ht(self, voie, volts):
        volts = max(0.0, min(float(volts), HT_LIMITE))      # jamais plus de 1350 V
        self.boitier.programmer_ht(voie, volts)
        with self.verrou:
            self.ht_consigne[voie] = volts

    def _regler_seuil(self, voie, mv):
        self.boitier.programmer_seuil(voie, mv)
        with self.verrou:
            self.seuils[voie] = mv

    def _stabiliser_ht(self, phase="stabilisation des HT"):
        self._etape(phase=phase)
        limite = self._t() + 60
        while True:
            ht = [self.boitier.lire_ht(v) for v in range(4)]
            with self.verrou:
                self.ht_mesure = ht
            ecarts = [abs(ht[v] - self.ht_consigne[v]) for v in range(4) if self.ht_consigne[v] > 0]
            if all(e < ECART_HT_V for e in ecarts):
                break
            if self._t() > limite:
                self.journal("La HT lue ne rejoint pas la consigne en 60 s (lecture HT à vérifier) : on continue.")
                break
            self._attendre(1.0)
        self._attendre(STABILISATION_S)

    def _mesurer(self, duree):
        """Compte pendant `duree` secondes sans remise à zéro intermédiaire.

        Les compteurs du boîtier sont sur 16 bits : on les lit régulièrement et on cumule les
        différences (modulo 65 536), ce qui évite tout débordement.
        """
        b = self.boitier
        b.raz_tout()
        t0 = self._t()
        precedent, total = [0] * 13, [0] * 13
        prochaine_ht, somme_ht, n_ht = t0, [0.0] * 4, 0
        while True:
            t = self._t()
            valeurs = [b.lire_voie(v) for v in range(4)] + [b.lire_fonction(f) for f in range(9)]
            for i, v in enumerate(valeurs):
                total[i] += (v - precedent[i]) % 65536
            precedent = valeurs
            if t >= prochaine_ht:
                ht = [b.lire_ht(v) for v in range(4)]
                somme_ht = [a + h for a, h in zip(somme_ht, ht)]
                n_ht += 1
                prochaine_ht = t + 2.0
                with self.verrou:
                    self.ht_mesure = ht
            ecoule = t - t0
            with self.verrou:
                self.compteurs = list(total)
                if self.prog:
                    self.prog["ecoule_point"] = min(ecoule, duree)
                    self.prog["partiel"] = dict(zip(CLES, total))
            if ecoule >= duree:
                break
            self._attendre(min(0.25, duree - ecoule))
        return dict(zip(CLES, total)), ecoule, [h / max(n_ht, 1) for h in somme_ht]

    def _etape(self, **champs):
        with self.verrou:
            if self.prog:
                self.prog.update(champs)

    def _point_fait(self, duree_sim):
        with self.verrou:
            if self.prog:
                self.prog["points_faits"] += 1
                self.prog["restant_sim"] = max(0.0, self.prog["restant_sim"] - duree_sim)

    # ------------------------------------------------------------ programme
    def _executer_programme(self, demande):
        plan = demande["plan"]
        debut = datetime.datetime.now()
        with self.verrou:
            self.prog = {"etapes": [p["type"] for p in plan], "index": 0, "titre": "", "detail": "",
                         "phase": "", "debut": time.time(), "points_faits": 0,
                         "points_prevus": sum(p["points_prevus"] for p in plan),
                         "restant_sim": sum(p["duree_prevue"] for p in plan),
                         "duree_point": 0, "ecoule_point": 0, "partiel": None}
            self.message = ""
        self.journal("Début de l'étalonnage : " + ", ".join(p["type"] for p in plan))
        raison = "terminé"
        try:
            for i, p in enumerate(plan):
                self._etape(index=i)
                if p["type"] == "ht":
                    self._etalonner_ht(p)
                elif p["type"] == "seuils":
                    self._etalonner_seuils(p)
                else:
                    self._mesurer_temps_mort(p)
        except Interruption:
            raison = "arrêté avant la fin"
        except ErreurBoitier as e:
            raison = f"interrompu : le boîtier ne répond plus ({e})"
            with self.verrou:
                self.message = "Étalonnage interrompu : le boîtier ne répond plus. Vérifiez le câble puis reconnectez."
        except Exception as e:
            raison = f"interrompu par une erreur ({e})"
            self.journal("Erreur interne : " + traceback.format_exc())
        self.journal(f"Étalonnage {raison}")
        try:
            if demande["couper_ht"] and raison == "terminé":
                for v in range(4):
                    self._regler_ht(v, 0)
                self.journal("Fin du programme : HT remises à 0 V")
        except Exception:
            pass
        self._ecrire_resume(debut, raison)
        with self.verrou:
            self.prog = None
            if raison != "terminé" and not self.message:
                self.message = f"Étalonnage {raison}."

    # -------------------------------------------------------- 1. hautes tensions
    def _etalonner_ht(self, p):
        for v in range(4):
            self._regler_seuil(v, p["seuil"])
        chemin = self._creer_fichier("etalonnage_HT", [
            f"Étalonnage des hautes tensions : de {p['tensions'][0]:g} à {p['tensions'][-1]:g} V, "
            f"comptage de {p['duree']:g} s par point",
            f"PM de référence à {p['ht_ref']:g} V ; seuils de toutes les voies à {p['seuil']:g} mV",
            "RAPPORT = N(coïncidence avec le PM étudié) / N(coïncidence des PM de référence)", "",
            "PM ETUDIE\tHT CONSIGNE (V)\tHT LUE (V)\tDUREE (s)\tCOMPTAGE PM\tREFERENCES\tN REFERENCES\t"
            "COINCIDENCE\tN COINCIDENCE\tRAPPORT\tINCERTITUDE"])
        for pm in p["pms"]:
            if pm < 3:
                refs = tuple(x for x in (0, 1, 2) if x != pm)
                f_ref, f_coinc, autres = PAIRE[refs], 6, [3]
            else:
                refs, f_ref, f_coinc, autres = (0, 1, 2), 6, 7, []
            nom_ref, nom_coinc = NOMS_CLES[f"f{f_ref}"], NOMS_CLES[f"f{f_coinc}"]
            with self.verrou:
                self.resultats["ht"][str(pm)] = {"pm": pm, "refs": nom_ref, "coinc": nom_coinc,
                                                 "points": [], "analyse": analyse.analyser_ht([])}
            self.journal(f"HT {NOMS_VOIES[pm]} : références {nom_ref} à {p['ht_ref']:g} V")
            for r in refs:
                self._regler_ht(r, p["ht_ref"])
            for a in autres:
                self._regler_ht(a, 0)
            for k, volts in enumerate(p["tensions"]):
                self._etape(titre=f"Hautes tensions — {NOMS_VOIES[pm]}",
                            detail=f"{NOMS_VOIES[pm]} à {volts:g} V (point {k + 1}/{len(p['tensions'])}) ; "
                                   f"références {nom_ref} à {p['ht_ref']:g} V",
                            duree_point=p["duree"], ecoule_point=0, partiel=None)
                self._regler_ht(pm, volts)
                self._stabiliser_ht()
                self._etape(phase="comptage")
                comptes, duree, ht_lue = self._mesurer(p["duree"])
                n_ref, n_coinc = comptes[f"f{f_ref}"], comptes[f"f{f_coinc}"]
                r, err = analyse.rapport(n_coinc, n_ref)
                point = {"v": volts, "ht_lue": round(ht_lue[pm], 1), "duree": round(duree, 1),
                         "n_pm": comptes[f"v{pm}"], "n_ref": n_ref, "n_coinc": n_coinc, "rapport": r, "err": err}
                with self.verrou:
                    res = self.resultats["ht"][str(pm)]
                    res["points"].append(point)
                    res["analyse"] = analyse.analyser_ht(res["points"], p["marge"])
                self._ajouter(chemin, "\t".join([NOMS_VOIES[pm], f"{volts:g}", _fr(ht_lue[pm], 0), _fr(duree, 1),
                                                  str(point["n_pm"]), nom_ref, str(n_ref), nom_coinc, str(n_coinc),
                                                  _fr(r, 4) if r is not None else "", _fr(err, 4) if err else ""]))
                self.journal(f"{NOMS_VOIES[pm]} {volts:g} V : {nom_coinc} {n_coinc} / {nom_ref} {n_ref}")
                self._point_fait(p["duree"] + 10)
            a = self.resultats["ht"][str(pm)]["analyse"]
            with self.verrou:
                self.reglages["ht"][pm] = a.get("conseil") if a.get("ok") else None
            self._ajouter(chemin, f"Résultat {NOMS_VOIES[pm]} : {a.get('message', '')}"
                          + "".join(" " + x for x in a.get("avertissements", [])))
            self._regler_ht(pm, p["ht_ref"])        # sert de référence pour le PM suivant

    # ------------------------------------------------------------- 2. seuils
    def _ht_effectives(self, p):
        if p.get("ht_auto"):
            return [self.reglages["ht"][i] if self.reglages["ht"][i] else p["ht"][i] for i in range(4)]
        return p["ht"]

    def _etalonner_seuils(self, p):
        ht = self._ht_effectives(p)
        voies = [i for i in range(4) if ht[i] > 0]
        for i in range(4):
            self._regler_ht(i, ht[i])
        self._etape(titre="Seuils", detail="Mise sous tension des PM", duree_point=p["duree"], ecoule_point=0,
                    partiel=None)
        self._stabiliser_ht()
        cle = p["cle"]
        chemin = self._creer_fichier("etalonnage_seuils", [
            "Étalonnage des seuils de discrimination : " + ", ".join(f"{s:g}" for s in p["seuils"])
            + f" mV, comptage de {p['duree']:g} s par point",
            "HT : " + "\t".join(f"{NOMS_VOIES[i]} {ht[i]:g} V" for i in range(4)),
            f"Seuil appliqué à : {', '.join(NOMS_VOIES[i] for i in voies)} ; compteur analysé : {NOMS_CLES[cle]}", "",
            "SEUIL (mV)\tDUREE (s)\t" + "\t".join(NOMS_CLES[c] for c in CLES)])
        with self.verrou:
            self.resultats["seuils"] = {"cle": cle, "nom": NOMS_CLES[cle], "ht": ht, "points": [],
                                        "analyse": analyse.analyser_seuils([], cle)}
        for k, s in enumerate(p["seuils"]):
            self._etape(detail=f"Seuil {s:g} mV (point {k + 1}/{len(p['seuils'])})", phase="réglage du seuil",
                        ecoule_point=0, partiel=None)
            for i in voies:
                self._regler_seuil(i, s)
            self._attendre(2.0)
            self._etape(phase="comptage")
            comptes, duree, _ = self._mesurer(p["duree"])
            with self.verrou:
                res = self.resultats["seuils"]
                res["points"].append({"s": s, "duree": round(duree, 1), "comptes": comptes})
                res["analyse"] = analyse.analyser_seuils(res["points"], cle)
            self._ajouter(chemin, f"{s:g}\t{_fr(duree, 1)}\t" + "\t".join(str(comptes[c]) for c in CLES))
            self.journal(f"Seuil {s:g} mV : {NOMS_CLES[cle]} {comptes[cle]}")
            self._point_fait(p["duree"] + 2)
        a = self.resultats["seuils"]["analyse"]
        with self.verrou:
            self.reglages["seuil"] = a.get("conseil") if a.get("ok") else None
        self._ajouter(chemin, "Résultat : " + a.get("message", "") + "".join(" " + x for x in a.get("avertissements", [])))
        if self.reglages["seuil"]:
            for i in voies:
                self._regler_seuil(i, self.reglages["seuil"])

    # ---------------------------------------------------------- 3. temps mort
    def _mesurer_temps_mort(self, p):
        ht = self._ht_effectives(p)
        seuil = self.reglages["seuil"] if p.get("seuil_auto") and self.reglages["seuil"] else p["seuil"]
        for i in range(4):
            self._regler_ht(i, ht[i])
            self._regler_seuil(i, seuil)
        self._etape(titre="Temps mort", detail="Mise sous tension des PM", duree_point=p["duree"], ecoule_point=0,
                    partiel=None)
        self._stabiliser_ht()
        cle = p["cle"]
        index = CLES.index(cle)
        chemin = self._creer_fichier("temps_mort", [
            f"Temps mort : comptage {NOMS_CLES[cle]} pendant {p['duree']:g} s pour chaque intervalle",
            "HT : " + "\t".join(f"{NOMS_VOIES[i]} {ht[i]:g} V" for i in range(4)) + f"\tSeuils : {seuil:g} mV",
            (f"Temps mort ajouté volontairement entre la lecture et la remise à zéro : {p['ajout']:g} s"
             if p["ajout"] else "Lecture puis remise à zéro immédiate de chaque compteur (comme le logiciel Cosmodétecteur)"),
            "", "INTERVALLE (s)\tNOMBRE D'INTERVALLES\tDUREE TOTALE (s)\tCOMPTAGE TOTAL\tTEMPS MORT DE LECTURE MESURE (s)"])
        with self.verrou:
            self.resultats["temps_mort"] = {"cle": cle, "nom": NOMS_CLES[cle], "ajout": p["ajout"], "ht": ht,
                                            "seuil": seuil, "duree": p["duree"], "points": [], "tau_lecture": None,
                                            "analyse": analyse.analyser_temps_mort([])}
        b = self.boitier
        fenetres = []
        for k, dt in enumerate(p["intervalles"]):
            n = max(1, int(round(p["duree"] / dt)))
            self._etape(detail=f"Intervalle de {dt:g} s : {n} lectures (point {k + 1}/{len(p['intervalles'])})",
                        phase="comptage", ecoule_point=0, partiel=None)
            b.raz_tout()
            t0 = self._t()
            prochaine, total, morts = t0 + dt, 0, []
            for j in range(n):
                self._attendre(prochaine - self._t())
                # fin d'intervalle : lecture puis remise à zéro, compteur par compteur
                valeurs, debut_mort = [], None
                if p["ajout"]:
                    for c in range(13):
                        t_av = self._t()
                        valeurs.append(b.lire_voie(c) if c < 4 else b.lire_fonction(c - 4))
                        if c == index:
                            debut_mort = t_av
                    fin_lecture = self._t()
                    if j < n - 1:
                        self._attendre(p["ajout"])
                        for c in range(13):
                            b.raz_voie(c) if c < 4 else b.raz_fonction(c - 4)
                            if c == index:
                                morts.append(self._t() - debut_mort)
                else:
                    for c in range(13):
                        t_av = self._t()
                        valeurs.append(b.lire_voie(c) if c < 4 else b.lire_fonction(c - 4))
                        if c == index:
                            fin_lecture = self._t()
                        if j < n - 1:
                            b.raz_voie(c) if c < 4 else b.raz_fonction(c - 4)
                            if c == index:
                                morts.append(self._t() - t_av)
                total += valeurs[index]
                if j == n - 1:
                    duree_totale = fin_lecture - t0
                prochaine += dt
                with self.verrou:
                    self.compteurs = valeurs
                    if self.prog:
                        self.prog["ecoule_point"] = min(self._t() - t0, p["duree"])
                        self.prog["partiel"] = {cle: total}
            fenetres += morts
            point = {"dt": dt, "intervalles": n, "n": n - 1, "duree": round(duree_totale, 2), "N": total,
                     "tau_lecture": (sum(morts) / len(morts)) if morts else None}
            with self.verrou:
                res = self.resultats["temps_mort"]
                res["points"].append(point)
                res["analyse"] = analyse.analyser_temps_mort(res["points"])
                res["tau_lecture"] = sum(fenetres) / len(fenetres) if fenetres else None
            self._ajouter(chemin, f"{dt:g}\t{n}\t{_fr(duree_totale, 2)}\t{total}\t"
                          + (_fr(point['tau_lecture'], 3) if point["tau_lecture"] is not None else ""))
            self.journal(f"Temps mort, intervalle {dt:g} s : {total} coups")
            self._point_fait(p["duree"])
        res = self.resultats["temps_mort"]
        a = res["analyse"]
        with self.verrou:
            self.reglages["tau"] = {"tau": a.get("tau"), "err": a.get("err_tau"), "lecture": res["tau_lecture"]} \
                if a.get("ok") else None
        self._ajouter(chemin, "Résultat (ajustement N = R x (D - n x tau)) : " + a.get("message", ""))
        if res["tau_lecture"] is not None:
            self._ajouter(chemin, f"Temps mort de lecture mesuré directement : {_fr(res['tau_lecture'], 3)} s")

    # ------------------------------------------------------------ fichiers
    def _creer_fichier(self, prefixe, lignes_entete):
        maintenant = datetime.datetime.now()
        chemin = os.path.join(self.dossier, f"{prefixe}_{maintenant:%Y-%m-%d_%Hh%Mm%S}.txt")
        lignes = [f"Cosmodétecteur-étalonnage",
                  f"Date du: {JOURS[maintenant.weekday()]} {maintenant.day} {MOIS[maintenant.month - 1]} {maintenant.year}",
                  f"Heure:{maintenant:%H:%M}" + ("\t(simulation)" if self.simulation else ""), ""] + lignes_entete
        with open(chemin, "w", encoding="cp1252", errors="replace", newline="") as f:
            f.write(_texte_fichier("\r\n".join(lignes) + "\r\n"))
        return chemin

    @staticmethod
    def _ajouter(chemin, ligne):
        with open(chemin, "a", encoding="cp1252", errors="replace", newline="") as f:
            f.write(_texte_fichier(ligne) + "\r\n")

    def _ecrire_resume(self, debut, raison):
        r = self.reglages
        lignes = [f"Étalonnage commencé le {debut:%d/%m/%Y à %H:%M}, {raison}.", "", "RÉGLAGES CONSEILLÉS"]
        for i in range(4):
            if r["ht"][i]:
                lignes.append(f"HT {NOMS_VOIES[i]}\t{r['ht'][i]:g} V")
        if r["seuil"]:
            lignes.append(f"Seuil\t{r['seuil']:g} mV")
        if r["tau"]:
            lignes.append(f"Temps mort (ajustement)\t{_fr(r['tau']['tau'], 2)} ± {_fr(r['tau']['err'], 2)} s")
            if r["tau"]["lecture"] is not None:
                lignes.append(f"Temps mort de lecture mesuré\t{_fr(r['tau']['lecture'], 3)} s")
        lignes += ["", "DÉTAIL"]
        for pm, res in sorted(self.resultats["ht"].items()):
            lignes.append(f"HT {NOMS_VOIES[int(pm)]} : " + res["analyse"].get("message", ""))
        if self.resultats["seuils"]:
            lignes.append("Seuils : " + self.resultats["seuils"]["analyse"].get("message", ""))
        if self.resultats["temps_mort"]:
            lignes.append("Temps mort : " + self.resultats["temps_mort"]["analyse"].get("message", ""))
        self._ecrire_resultats(lignes)

    def _ecrire_resultats(self, lignes):
        chemin = self._creer_fichier("etalonnage_resultats", lignes)
        self.journal(f"Résumé écrit dans {os.path.basename(chemin)}")

    def fichiers(self):
        resultat = []
        for nom in sorted(os.listdir(self.dossier), reverse=True):
            chemin = os.path.join(self.dossier, nom)
            if os.path.isfile(chemin) and nom.endswith(".txt"):
                st = os.stat(chemin)
                resultat.append({"nom": nom, "taille": st.st_size, "date": st.st_mtime})
        return resultat
