@echo off
rem Lance Cosmodetecteur-etalonnage sous Windows (laisser la fenetre ouverte)
chcp 65001 >nul
cd /d "%~dp0"
set PY=py
where py >nul 2>nul || set PY=python
%PY% --version >nul 2>nul || goto :sanspython
%PY% -c "import serial" >nul 2>nul || (
  echo Premiere utilisation : installation du module pyserial...
  %PY% -m pip install pyserial
)
%PY% cosmodetecteur_etalonnage.py %*
echo.
echo Logiciel arrete.
pause
exit /b
:sanspython
echo Python n'est pas installe sur cet ordinateur.
echo Installez-le depuis https://www.python.org/downloads/ en cochant "Add python.exe to PATH".
pause
