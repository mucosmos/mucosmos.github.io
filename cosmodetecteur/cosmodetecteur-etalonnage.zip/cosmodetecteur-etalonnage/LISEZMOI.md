# Cosmodétecteur-étalonnage

Logiciel compagnon du programme **Cosmodétecteur**. Il réalise seul, sans surveillance, les
étalonnages décrits dans le livret pédagogique du cosmodétecteur, puis conseille les réglages :

1. **Hautes tensions des PM** (livret § 2.2) : plateau d'efficacité de chaque photomultiplicateur ;
2. **Seuils de discrimination** (livret § 3.1) : plateau des coïncidences en fonction du seuil ;
3. **Temps mort de l'acquisition** (livret § 2.3) : coups perdus à chaque lecture des compteurs.

Les trois étapes peuvent s'enchaîner automatiquement (compter 4 à 5 heures avec les durées par
défaut) : l'ordinateur peut tourner seul, la nuit par exemple. Les HT ne dépassent **jamais 1350 V**.

Ce logiciel et le logiciel Cosmodétecteur utilisent le même port série : **un seul des deux peut être
connecté au boîtier à la fois**.

## Installation

- **Paquet .deb** (Linux Mint, Ubuntu, Debian) : double-cliquez sur
  `cosmodetecteur-etalonnage_1.0.0_all.deb`, puis « Installer le paquet ». Le logiciel apparaît dans le
  menu (Éducation ou Sciences) sous le nom « Cosmodétecteur-étalonnage ». Les fichiers sont rangés
  dans `Documents/Cosmodetecteur-etalonnage`. Pour désinstaller : `sudo apt remove cosmodetecteur-etalonnage`.
- **Sans paquet** : comme pour le logiciel Cosmodétecteur, `lancer.sh` (Linux) ou `lancer.bat` (Windows).
  `fabriquer_exe.bat` fabrique un `.exe` Windows (voir le LISEZMOI du Cosmodétecteur).

Le navigateur s'ouvre sur **http://localhost:8003**. Laissez la fenêtre du terminal ouverte, et
désactivez la mise en veille de l'ordinateur pendant un long étalonnage.

## Utilisation

1. Choisissez le port du boîtier puis **Connecter** (les HT sont mises à 0 V). Pour découvrir le
   logiciel sans détecteur, cochez **Simulation**, et **accélérée** pour que le temps simulé s'écoule
   60 fois plus vite (un étalonnage complet dure alors environ 5 minutes).
2. Onglet **Programme** : cochez les étapes voulues et réglez leurs paramètres (les valeurs par défaut
   sont celles du livret), puis **Lancer l'étalonnage**. La durée estimée est affichée.
3. Suivez l'avancement dans le cadre **Déroulement**, et les courbes dans les onglets
   **Hautes tensions**, **Seuils** et **Temps mort**, qui se complètent au fil des mesures.
4. À la fin, le cadre **Réglages conseillés** donne les HT de chaque PM, le seuil et le temps mort.
   **Appliquer au boîtier** les règle immédiatement ; reportez-les dans le logiciel Cosmodétecteur
   pour vos mesures. Par défaut, les HT sont remises à 0 V à la fin du programme.

## Méthodes

### Hautes tensions

Chaque PM coché est étudié à son tour. Sa HT varie (800 à 1300 V par pas de 50 V, 5 min par point)
pendant que les deux autres PM (parmi PM1, PM2, PM3) servent de référence à une HT fixe (1200 V).
Le logiciel calcule le rapport

    R = N(coïncidence triple PM1×PM2×PM3) / N(coïncidence des deux PM de référence)

Pour PM4 : R = N(PM1×PM2×PM3×PM4) / N(PM1×PM2×PM3). Une courbe en S
R = P / (1 + exp(−(V − V50)/w)) est ajustée sur les points. P est le plateau ; le **coude** est la
tension où la courbe atteint 95 % du plateau. **Tension conseillée = coude + 50 V** (marge réglable).
Sur l'exemple du livret (figure 2.2), cette méthode donne 960 V (« régler la tension du PM au-delà de 950 V »).

Pour un PM placé au milieu de la pile, P est l'efficacité du PM. Pour un PM placé au bord, P est plus
petit : certains muons qui traversent les deux autres ne le traversent pas. La position du coude, qui
sert au réglage, n'en dépend pas : il n'est donc pas nécessaire de déplacer les PM.

### Seuils

Le même seuil est appliqué à tous les PM allumés (2 à 50 mV, 5 min par point), avec les HT conseillées
à l'étape 1. Le logiciel cherche la plus longue suite de points dont les comptages de coïncidences
(PM1×PM2 par défaut) sont compatibles avec une constante, compte tenu de leur incertitude √N (test
du χ²) : c'est le **plateau**. Seuil conseillé : milieu du plateau. Si le plateau continue jusqu'au
dernier seuil mesuré, son milieu n'est pas connu : le seuil conseillé est alors deux points après le
début du plateau. Sur l'exemple du livret (figure 3.1), cette méthode trouve un plateau de 2 à 14 mV
et conseille 8 mV.

### Temps mort

Pour chaque intervalle Δt (5, 10, 15, 20, 30, 60 s), le logiciel compte pendant 10 min ; à la fin de
chaque intervalle, il lit chaque compteur puis le remet à zéro, comme le logiciel Cosmodétecteur.
Les coups arrivés entre la lecture et la remise à zéro sont perdus. Sur une durée D découpée en
n + 1 intervalles (n remises à zéro), on compte N = R × (D − n τ). Un ajustement par moindres carrés
pondérés donne R et τ. Le logiciel mesure aussi directement, avec l'horloge de l'ordinateur, le temps
écoulé entre la lecture et la remise à zéro.

Avec l'ancien logiciel LabVIEW, τ valait 2 à 3 s (livret, figure 2.3). Le logiciel Cosmodétecteur
remet chaque compteur à zéro juste après l'avoir lu : son temps mort n'est que de quelques
centièmes de seconde, trop petit pour se voir dans les comptages (τ trouvé compatible avec zéro). Pour
montrer le phénomène aux élèves, le réglage **temps mort ajouté** insère une pause connue entre la
lecture et la remise à zéro : en simulation, avec 2 s ajoutées, la méthode retrouve τ = 2,4 ± 0,3 s
(2,34 s mesurées directement).

## Fichiers produits

Fichiers texte avec tabulations (encodage Windows, comme ceux du Cosmodétecteur) :

- `etalonnage_HT_…` : pour chaque point, PM étudié, HT consigne et lue, comptages, rapport et incertitude ;
- `etalonnage_seuils_…` : pour chaque seuil, les 4 compteurs de voie et les 9 compteurs de fonction ;
- `temps_mort_…` : pour chaque intervalle, nombre de lectures, durée, comptage, temps lecture → remise à zéro ;
- `etalonnage_resultats_…` : résumé des réglages conseillés.

## Contenu

- `cosmodetecteur_etalonnage.py` : programme principal (serveur de l'interface web) ;
- `etalonnage.py` : déroulement des étalonnages, fichiers ;
- `analyse.py` : calculs (courbe en S, plateau, ajustement du temps mort) ;
- `boitier.py` : protocole du boîtier et simulateur (identique à celui du logiciel Cosmodétecteur) ;
- `web/index.html` : interface ;
- `lancer.sh`, `lancer.bat`, `fabriquer_exe.bat`, `cosmodetecteur-etalonnage.ico` ;
- `LICENSE` : licence GNU GPL version 3.

## Auteurs et licence

Cosmodétecteur-étalonnage — logiciel compagnon du programme Cosmodétecteur (adaptation du logiciel
**Roue Cosmique** [Sciences à l'École, CPPM] [Michel Jevaud, Marta Rodo Bordera, 2011] pour le
Cosmodétecteur [José Busto]) ; conception et direction du projet : **Cédric Vanden Driessche** (2026),
professeur de physique-chimie au lycée Charles de Gaulle à Caen (cedric.vanden-driessche@ac-normandie.fr) ;
développement du code : Claude (Anthropic), sous sa direction. Méthodes d'étalonnage tirées du livret
pédagogique du cosmodétecteur.

Ce programme est un logiciel libre : vous pouvez le redistribuer et le modifier selon les termes
de la Licence publique générale GNU (GPL), version 3 ou toute version ultérieure.
Il est distribué sans aucune garantie. Le texte complet de la licence se trouve dans le fichier `LICENSE`.
