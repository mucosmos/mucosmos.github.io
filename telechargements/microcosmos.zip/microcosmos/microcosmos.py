#!/usr/bin/env python3
# Microcosmos — interface Python-web
# Détecteur Microcosmos et programme Arduino : Cédric Vanden Driessche ;
# interface Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
#
# Ce programme est un logiciel libre : vous pouvez le redistribuer et/ou le
# modifier selon les termes de la Licence publique générale GNU (GPL) publiée
# par la Free Software Foundation, version 3 ou (à votre choix) toute version
# ultérieure. Il est distribué SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Microcosmos — comptage Geiger avec interface dans le navigateur :
étude des rayons cosmiques (2 tubes, coïncidences) et étude de la radioactivité (séries de 10 s).

Lancement :   python3 microcosmos.py
Puis ouvrir http://localhost:8001 (le navigateur s'ouvre tout seul).

Options :
  --port-web 8001      port de l'interface web
  --reseau             rend l'interface accessible aux autres ordinateurs / tablettes du réseau
  --dossier CHEMIN     dossier où sont écrits les fichiers de mesure (défaut : ./mesures)
  --pas-de-navigateur  ne pas ouvrir le navigateur automatiquement
"""

import argparse
import json
import os
import signal
import socket
import sys
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)

from station import Erreur, Station  # noqa: E402

station = None


def lister_ports():
    try:
        from serial.tools import list_ports
    except ImportError:
        return []
    ports = []
    for p in sorted(list_ports.comports(), key=lambda p: p.device):
        description = p.description if p.description and p.description != "n/a" else ""
        ports.append({"device": p.device, "description": description})
    return ports


class Gestionnaire(BaseHTTPRequestHandler):
    server_version = "Microcosmos/1.2"

    def log_message(self, *args):
        pass

    def _json(self, donnees, code=200):
        corps = json.dumps(donnees).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(corps)))
        self.end_headers()
        self.wfile.write(corps)

    def _fichier(self, chemin, type_mime, telechargement=None):
        with open(chemin, "rb") as f:
            corps = f.read()
        self.send_response(200)
        self.send_header("Content-Type", type_mime)
        self.send_header("Content-Length", str(len(corps)))
        self.send_header("Cache-Control", "no-store")
        if telechargement:
            self.send_header("Content-Disposition", f'attachment; filename="{telechargement}"')
        self.end_headers()
        self.wfile.write(corps)

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(url.query)
        chemin = url.path
        if chemin in ("/", "/index.html"):
            return self._fichier(os.path.join(ICI, "web", "index.html"), "text/html; charset=utf-8")
        if chemin == "/api/etat":
            return self._json(station.etat())
        if chemin == "/api/historique":
            i = int(params.get("depuis", ["0"])[0])
            return self._json(station.historique_depuis(i))
        if chemin == "/api/ports":
            return self._json(lister_ports())
        if chemin == "/api/journal":
            return self._json(list(station.journal_lignes))
        if chemin == "/api/fichiers":
            return self._json(station.fichiers())
        if chemin in ("/arduino/DetectionCosmiques3_0.ino", "/arduino/MicroCosmosRadioactivite.ino"):
            nom = chemin.rsplit("/", 1)[1]
            return self._fichier(os.path.join(ICI, "arduino", nom[:-4], nom), "text/plain; charset=utf-8", nom)
        if chemin.startswith("/fichiers/"):
            nom = os.path.basename(urllib.parse.unquote(chemin[len("/fichiers/"):]))
            complet = os.path.join(station.dossier, nom)
            if nom and os.path.isfile(complet):
                return self._fichier(complet, "text/plain; charset=windows-1252", nom)
        self.send_error(404)

    def do_POST(self):
        longueur = int(self.headers.get("Content-Length") or 0)
        try:
            donnees = json.loads(self.rfile.read(longueur) or b"{}")
        except ValueError:
            donnees = {}
        chemin = urllib.parse.urlparse(self.path).path
        try:
            resultat = self._action(chemin, donnees)
            self._json({"ok": True, "resultat": resultat})
        except Erreur as e:
            self._json({"ok": False, "erreur": str(e)})
        except (KeyError, ValueError, TypeError) as e:
            self._json({"ok": False, "erreur": f"Valeur invalide ({e})."})
        except Exception as e:
            station.journal(f"Erreur : {e!r}")
            self._json({"ok": False, "erreur": f"Erreur inattendue : {e}"})

    def _action(self, chemin, d):
        if chemin == "/api/connecter":
            station.message = ""
            return station.connecter(d.get("port"), bool(d.get("simulation")))
        if chemin == "/api/deconnecter":
            return station.deconnecter()
        if chemin == "/api/raz":
            return station.raz()
        if chemin == "/api/manip/lancer":
            return station.lancer_manip(d["duree"], d["intervalle"], bool(d.get("fichier")), d.get("commentaire", ""))
        if chemin == "/api/manip/arreter":
            return station.arreter_manip()
        if chemin == "/api/serie/lancer":
            return station.lancer_serie(d["nombre"], bool(d.get("fichier")), d.get("commentaire", ""),
                                        d.get("tube", 1))
        if chemin == "/api/serie/arreter":
            return station.arreter_serie()
        if chemin == "/api/serie/effacer":
            return station.effacer_serie()
        if chemin == "/api/journal/brut":
            station.journal_brut = bool(d.get("actif"))
            return None
        raise Erreur("Action inconnue.")


def adresse_locale():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def main():
    global station
    parser = argparse.ArgumentParser(description="Microcosmos : rayons cosmiques et radioactivité")
    parser.add_argument("--port-web", type=int, default=8001)
    parser.add_argument("--reseau", action="store_true")
    parser.add_argument("--dossier", default=os.path.join(ICI, "mesures"))
    parser.add_argument("--pas-de-navigateur", action="store_true")
    args = parser.parse_args()

    try:
        import serial
        if not hasattr(serial, "Serial"):
            raise ImportError(f"le module « serial » trouvé ({getattr(serial, '__file__', '?')}) n'est pas pyserial")
        import serial.tools.list_ports  # noqa: F401
    except Exception as e:
        print(f"ATTENTION : pyserial n'est pas utilisable par {sys.executable}")
        print(f"  Détail : {e}")
        print("  Sous Linux Mint :  sudo apt install python3-serial")
        print("  Ailleurs        :  python3 -m pip install pyserial")
        print("Seul le mode simulation sera disponible.\n")

    station = Station(os.path.abspath(args.dossier))
    hote = "0.0.0.0" if args.reseau else "127.0.0.1"
    try:
        serveur = ThreadingHTTPServer((hote, args.port_web), Gestionnaire)
    except OSError as e:
        # le plus souvent : le logiciel tourne déjà -> on rouvre simplement son interface
        print(f"Le port {args.port_web} est déjà utilisé ({e}) : le logiciel est sans doute déjà lancé.")
        print("Ouverture de l'interface existante : http://localhost:%d" % args.port_web)
        if not args.pas_de_navigateur:
            webbrowser.open(f"http://localhost:{args.port_web}")
        import time
        time.sleep(3)
        sys.exit(0)
    serveur.daemon_threads = True

    def interrompre(*_):
        raise KeyboardInterrupt
    for nom in ("SIGTERM", "SIGHUP"):
        if hasattr(signal, nom):
            signal.signal(getattr(signal, nom), interrompre)
    adresse = f"http://localhost:{args.port_web}"
    print("Microcosmos — détecteur et programmes Arduino : Cédric Vanden Driessche ;")
    print("interface Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),")
    print("professeur de physique-chimie au lycée Charles de Gaulle à Caen ;")
    print("développement du code : Claude (Anthropic), sous sa direction.")
    print("Logiciel libre sous licence GNU GPL v3 ou ultérieure.\n")
    print("Microcosmos prêt.")
    print(f"  Interface : {adresse}")
    if args.reseau and adresse_locale():
        print(f"  Depuis un autre appareil du réseau : http://{adresse_locale()}:{args.port_web}")
    print(f"  Fichiers de mesure : {station.dossier}")
    print("Fermez cette fenêtre (ou Ctrl+C) pour quitter.")
    if not args.pas_de_navigateur:
        threading.Timer(0.8, lambda: webbrowser.open(adresse)).start()
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        print("\nArrêt du logiciel.")
        station.deconnecter()
        serveur.server_close()


if __name__ == "__main__":
    main()
