# Microcosmos — interface Python-web
# Détecteur Microcosmos et programme Arduino : Cédric Vanden Driessche ;
# interface Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
# Ce programme est un logiciel libre, distribué selon les termes de la GNU GPL version 3
# ou ultérieure, SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Lecture des données envoyées par l'Arduino du Microcosmos (1 ou 2 tubes Geiger), à 9600 bauds.

Programmes Arduino reconnus :

* DetectionCosmiques3_0.ino (recommandé, sert aux deux études) : chaque seconde
      D;seconde;impulsions GM1;impulsions GM2;coincidences
* MicroCosmosRadioactivite.ino (un seul tube, étude de la radioactivité seulement) : toutes les 10 s
      nombre impulsion : 37  duree experience : 120 s
* DetectionCosmiques2_0.ino (ancien, pour le moniteur série) : signalé, non utilisable.

Ce module fournit aussi un détecteur simulé qui produit les lignes « D;... ».
"""

import math
import os
import random
import re
import time

DUREE_FENETRE_S = 10        # durée d'une mesure de radioactivité

_RE_RADIO = re.compile(r"nombre impulsion\s*:\s*(\d+)", re.I)   # pas « nombre impulsion 1 : » (2.0)


def analyser_ligne(ligne):
    """Renvoie ('seconde', (s, n1, n2, n12)), ('fenetre', n) ou None."""
    if ligne.startswith("D;"):
        morceaux = ligne.strip().split(";")
        if len(morceaux) == 5:
            try:
                return ("seconde", tuple(int(x) for x in morceaux[1:]))
            except ValueError:
                return None
        return None
    m = _RE_RADIO.search(ligne)
    if m:
        return ("fenetre", int(m.group(1)))
    return None


def ancien_programme(ligne):
    """Vrai si la ligne vient du programme Arduino DetectionCosmiques 2.0."""
    return "nombre de coincidences" in ligne or "nombre impulsion 1" in ligne or "but exp" in ligne


class Liaison:
    """Port série relié à l'Arduino (lecture ligne par ligne)."""

    def __init__(self, port):
        self.port = port
        self._tampon = b""

    @classmethod
    def ouvrir(cls, nom_port):
        import serial  # pyserial
        port = serial.Serial(nom_port, baudrate=9600, timeout=0.2)
        return cls(port)

    def lire_ligne(self):
        """Renvoie une ligne complète (texte) ou None si rien n'est arrivé."""
        while b"\n" not in self._tampon:
            morceau = self.port.read(self.port.in_waiting or 1)
            if not morceau:
                return None
            self._tampon += morceau
            if len(self._tampon) > 4096:          # pas de fin de ligne : on repart à zéro
                self._tampon = b""
                return None
        ligne, self._tampon = self._tampon.split(b"\n", 1)
        return ligne.decode("latin-1", errors="replace").strip()

    def fermer(self):
        try:
            self.port.close()
        except Exception:
            pass


def _poisson(lam):
    if lam <= 0:
        return 0
    if lam > 30:
        return max(0, int(round(random.gauss(lam, math.sqrt(lam)))))
    l, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= random.random()
        if p <= l:
            return k
        k += 1


class LiaisonSimulee:
    """Faux détecteur : mêmes lignes que DetectionCosmiques3_0, avec des taux plausibles.

    Chaque tube voit le rayonnement ambiant (environ 25 coups/min) ; les muons qui
    traversent les deux tubes donnent environ 1,5 coïncidence par minute.
    La durée d'une « seconde » peut être raccourcie pour les essais
    (variable d'environnement MICROCOSMOS_PERIODE) ; MICROCOSMOS_SOURCE ajoute une source
    radioactive simulée près du tube 1 (en coups/s).
    """

    BRUIT_PAR_S = 0.40       # coups/s propres à chaque tube
    MUONS_PAR_S = 0.025      # muons traversant les deux tubes
    EFFICACITE = 0.95

    def __init__(self):
        self.periode = float(os.environ.get("MICROCOSMOS_PERIODE", "1"))
        self.source = float(os.environ.get("MICROCOSMOS_SOURCE", "0"))   # coups/s ajoutés au tube 1 (essais)
        self.demarrage = time.monotonic()
        self.seconde = 0
        self.lignes = ["# MICROCOSMOS 3.0 (simulation) - D;seconde;impulsions GM1;impulsions GM2;coincidences"]

    def lire_ligne(self):
        if self.lignes:
            return self.lignes.pop(0)
        prochaine = self.demarrage + (self.seconde + 1) * self.periode
        attente = prochaine - time.monotonic()
        if attente > 0:
            time.sleep(min(attente, 0.2))
            return None
        self.seconde += 1
        n1 = _poisson(self.BRUIT_PAR_S + self.source)
        n2 = _poisson(self.BRUIT_PAR_S)
        n12 = 0
        for _ in range(_poisson(self.MUONS_PAR_S)):
            vu1 = random.random() < self.EFFICACITE
            vu2 = random.random() < self.EFFICACITE
            n1 += vu1
            n2 += vu2
            n12 += vu1 and vu2
        # coïncidences fortuites dans la fenêtre de 1 ms
        if n1 and n2 and random.random() < n1 * n2 * 0.001:
            n12 += 1
        return f"D;{self.seconde};{n1};{n2};{n12}"

    def fermer(self):
        pass
