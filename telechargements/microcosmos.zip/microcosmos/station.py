# Microcosmos — interface Python-web
# Détecteur Microcosmos et programme Arduino : Cédric Vanden Driessche ;
# interface Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
# Ce programme est un logiciel libre, distribué selon les termes de la GNU GPL version 3
# ou ultérieure, SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Acquisition : lit les comptages envoyés par l'Arduino et gère les deux études.

* Rayons cosmiques : totaux des deux tubes et des coïncidences, expériences (durée,
  intervalle) écrites dans un fichier « microcosmos_... ».
* Radioactivité : séries de mesures de 10 s sur un tube, écrites dans un fichier
  « radioactivite_... ».

Le temps de comptage est celui de l'Arduino : avec DetectionCosmiques3_0, une ligne
= une seconde mesurée par l'Arduino, donc une mesure de 10 s regroupe exactement 10 lignes.
Une seule expérience ou série à la fois.
"""

import collections
import datetime
import math
import os
import threading
import time

from detecteur import DUREE_FENETRE_S, Liaison, LiaisonSimulee, analyser_ligne, ancien_programme

JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]
NOMS = ["GM1", "GM2", "Coïncidences"]
PROG_SECONDES = "DetectionCosmiques3_0"
PROG_RADIO = "MicroCosmosRadioactivite"
MAX_MESURES = 1000


class Erreur(Exception):
    """Erreur à afficher telle quelle à l'utilisateur."""


def _date_fichier(maintenant):
    return [f"Date du: {JOURS[maintenant.weekday()]} {maintenant.day} {MOIS[maintenant.month - 1]} {maintenant.year}",
            f"Heure:{maintenant:%H:%M}"]


class Station:
    def __init__(self, dossier_mesures):
        self.dossier = dossier_mesures
        os.makedirs(self.dossier, exist_ok=True)
        self.verrou = threading.RLock()
        self.journal_lignes = collections.deque(maxlen=400)
        self.journal_brut = False
        self.liaison = None
        self.fil = None
        self.arret = threading.Event()
        self.serie = None                    # gardée après la fin (tableau à recopier)
        self._reinitialiser()

    def _reinitialiser(self):
        self.connecte = False
        self.port = None
        self.simulation = False
        self.message = ""
        self.version = None
        self.programme = None                # PROG_SECONDES ou PROG_RADIO quand reconnu
        self.derniere_donnee = None          # time.time() de la dernière ligne reçue
        self._ouverture = 0.0
        self.derniere = [0, 0, 0]            # comptages de la dernière seconde
        self.totaux = [0, 0, 0]              # depuis la dernière remise à zéro
        self.secondes = 0                    # durée correspondante (s)
        self.manip = None
        self.historique = []                 # lignes {t, heure, valeurs[3]}
        self.fenetre_n = None                # dernière mesure de 10 s (radioactivité)
        self.fenetre_instant = None
        self._radio_cumul = [0, 0]           # impulsions GM1, GM2 depuis le début de la fenêtre de 10 s
        self._radio_secondes = 0

    def journal(self, texte, brut=False):
        if brut and not self.journal_brut:
            return
        self.journal_lignes.append(f"{datetime.datetime.now():%H:%M:%S}  {texte}")

    # --------------------------------------------------------------- état
    def etat(self):
        with self.verrou:
            maintenant = time.time()
            message = self.message
            if self.connecte and not message:
                delai = 2.5 * DUREE_FENETRE_S if self.programme == PROG_RADIO else 8
                if self.derniere_donnee is None and maintenant - self._ouverture > 15:
                    message = ("Aucune donnée reçue de l'Arduino. Vérifiez le câble et le port choisi, et que "
                               "le programme DetectionCosmiques3_0 est bien téléversé dans l'Arduino.")
                elif self.derniere_donnee and maintenant - self.derniere_donnee > delai:
                    message = "L'Arduino n'envoie plus de données depuis quelques secondes (câble débranché ?)."
            manip = None
            if self.manip:
                m = self.manip
                manip = {"debut": m["debut"], "duree": m["duree"], "intervalle": m["intervalle"],
                         "ecoulees": m["ecoulees"], "dans_intervalle": m["n"], "lignes": m["lignes"],
                         "fichier": os.path.basename(m["fichier"]) if m["fichier"] else None,
                         "cumul": m["cumul"], "totaux": m["totaux"]}
            serie = None
            if self.serie:
                s = self.serie
                serie = {"voulu": s["voulu"], "en_cours": s["en_cours"], "attente": s["attente"],
                         "debut": s["debut"], "tube": s["tube"], "mesures": s["mesures"],
                         "fichier": os.path.basename(s["fichier"]) if s["fichier"] else None}
            # avancement de la fenêtre de 10 s en cours (pour la barre de progression)
            if self.programme == PROG_SECONDES:
                avance = self._radio_secondes
            elif self.fenetre_instant:
                avance = min(DUREE_FENETRE_S, maintenant - self.fenetre_instant)
            else:
                avance = None
            return {
                "connecte": self.connecte, "port": self.port, "simulation": self.simulation,
                "message": message, "heure": maintenant, "version": self.version,
                "programme": self.programme,
                "derniere": self.derniere, "totaux": self.totaux, "secondes": self.secondes,
                "manip": manip, "n_historique": len(self.historique), "noms": NOMS,
                "journal_brut": self.journal_brut,
                "fenetre": DUREE_FENETRE_S, "fenetre_n": self.fenetre_n,
                "fenetre_instant": self.fenetre_instant, "fenetre_avance": avance,
                "serie": serie,
            }

    def historique_depuis(self, i):
        with self.verrou:
            return {"historique": self.historique[i:], "n_historique": len(self.historique)}

    # ----------------------------------------------------------- connexion
    def connecter(self, port, simulation=False):
        self.deconnecter()
        if simulation:
            liaison, nom = LiaisonSimulee(), "simulation"
        else:
            if not port:
                raise Erreur("Choisissez un port série.")
            try:
                liaison = Liaison.ouvrir(port)
            except Exception as e:
                if "ermission" in str(e):
                    raise Erreur(f"Accès refusé au port {port}. Sous Linux, tapez dans un terminal :  "
                                 "sudo usermod -aG dialout $USER  puis fermez la session et reconnectez-vous. "
                                 "Sinon, fermez l'IDE Arduino (moniteur série) s'il est ouvert.")
                raise Erreur(f"Impossible d'ouvrir {port} : {e}")
            nom = port
        with self.verrou:
            self._reinitialiser()
            self.liaison = liaison
            self.connecte = True
            self.port = nom
            self.simulation = simulation
            self._ouverture = time.time()
        self.journal(f"Connexion à {nom} (l'Arduino redémarre : premières données dans 2 à 3 secondes)")
        self.arret.clear()
        self.fil = threading.Thread(target=self._boucle, daemon=True)
        self.fil.start()

    def deconnecter(self):
        if not self.liaison:
            return
        self.arret.set()
        if self.fil and self.fil is not threading.current_thread():
            self.fil.join(timeout=3)
        self._terminer_manip("déconnexion")
        self._terminer_serie("déconnexion")
        self.liaison.fermer()
        with self.verrou:
            self.liaison = None
            self.connecte = False
        self.journal("Déconnecté")

    def _verifier_libre(self):
        if not self.connecte:
            raise Erreur("Le détecteur n'est pas connecté.")
        if self.manip:
            raise Erreur("Une expérience « rayons cosmiques » est en cours : arrêtez-la d'abord.")
        if self.serie and self.serie["en_cours"]:
            raise Erreur("Une série « radioactivité » est en cours : arrêtez-la d'abord.")

    # ================================================= rayons cosmiques
    def raz(self):
        with self.verrou:
            if self.manip:
                raise Erreur("Une expérience est en cours : arrêtez-la avant de remettre à zéro.")
            self.totaux = [0, 0, 0]
            self.secondes = 0

    def lancer_manip(self, duree_s, intervalle_s, fichier, commentaire):
        self._verifier_libre()
        if self.programme == PROG_RADIO:
            raise Erreur("L'Arduino contient le programme MicroCosmosRadioactivite (un seul tube, mesures de 10 s). "
                         "Pour les rayons cosmiques, téléversez DetectionCosmiques3_0 (onglet Fichiers).")
        duree_s, intervalle_s = int(float(duree_s)), int(float(intervalle_s))
        if intervalle_s < 1:
            raise Erreur("L'intervalle doit être d'au moins 1 seconde.")
        if duree_s and duree_s < intervalle_s:
            raise Erreur("La durée de l'expérience doit être plus longue que l'intervalle.")
        chemin = self._creer_fichier_cosmique(commentaire, intervalle_s, duree_s) if fichier else None
        with self.verrou:
            self.historique = []
            self.totaux = [0, 0, 0]
            self.secondes = 0
            self.manip = {"debut": time.time(), "duree": duree_s, "intervalle": intervalle_s,
                          "ecoulees": 0, "n": 0, "cumul": [0, 0, 0], "totaux": [0, 0, 0],
                          "lignes": 0, "fichier": chemin}
        self.journal("Expérience lancée" + (f" (fichier {os.path.basename(chemin)})" if chemin else ""))

    def arreter_manip(self):
        self._terminer_manip("arrêt demandé")

    def _terminer_manip(self, raison):
        with self.verrou:
            if self.manip:
                m = self.manip
                self.journal(f"Fin de l'expérience ({raison}) : {m['ecoulees']} s, "
                             f"GM1 {m['totaux'][0]}, GM2 {m['totaux'][1]}, coïncidences {m['totaux'][2]}")
                if m["fichier"]:
                    t = m["totaux"]
                    lignes = ["", f"TOTAL ({m['ecoulees']} s)\t{t[0]}\t{t[1]}\t{t[2]}"]
                    if m["n"]:
                        lignes.insert(0, f"(dernier intervalle incomplet non enregistré : {m['n']} s)")
                    for ligne in lignes:
                        self._ajouter(m["fichier"], ligne)
                self.manip = None

    def _creer_fichier_cosmique(self, commentaire, intervalle_s, duree_s):
        maintenant = datetime.datetime.now()
        chemin = os.path.join(self.dossier, f"microcosmos_{maintenant:%Y-%m-%d_%Hh%Mm%S}.txt")
        lignes = ["Microcosmos - comptage Geiger"] + _date_fichier(maintenant)
        lignes += (commentaire or "").replace("\r\n", "\n").split("\n")
        lignes.append("")
        lignes.append(f"Intervalle de comptage : {intervalle_s} s\tDurée prévue : "
                      + (f"{duree_s} s" if duree_s else "sans limite"))
        lignes.append("")
        lignes.append("HEURE\tGM1\tGM2\tCOINCIDENCES")
        self._ecrire(chemin, lignes)
        return chemin

    # ====================================================== radioactivité
    def lancer_serie(self, nombre, fichier, commentaire, tube=1):
        self._verifier_libre()
        nombre, tube = int(nombre), int(tube)
        if not 1 <= nombre <= MAX_MESURES:
            raise Erreur(f"Le nombre de mesures doit être compris entre 1 et {MAX_MESURES}.")
        if tube not in (1, 2):
            raise Erreur("Choisissez le tube 1 ou le tube 2.")
        if self.programme == PROG_RADIO:
            tube = 1
        chemin = self._creer_fichier_radio(nombre, commentaire, tube) if fichier else None
        with self.verrou:
            # avec DetectionCosmiques3_0, la série commence à la seconde suivante ;
            # avec MicroCosmosRadioactivite, la fenêtre de 10 s en cours a déjà commencé : on l'ignore.
            self.serie = {"voulu": nombre, "en_cours": True, "attente": self.programme != PROG_SECONDES,
                          "debut": time.time(), "tube": tube, "mesures": [], "fichier": chemin}
            if self.programme == PROG_SECONDES:
                self._radio_cumul, self._radio_secondes = [0, 0], 0
        self.journal(f"Série de {nombre} mesures lancée (tube {tube})"
                     + (f", fichier {os.path.basename(chemin)}" if chemin else ""))

    def arreter_serie(self):
        self._terminer_serie("arrêt demandé")

    def effacer_serie(self):
        with self.verrou:
            if self.serie and self.serie["en_cours"]:
                raise Erreur("Arrêtez d'abord la série en cours.")
            self.serie = None

    def _terminer_serie(self, raison):
        with self.verrou:
            s = self.serie
            if not s or not s["en_cours"]:
                return
            s["en_cours"] = False
            s["attente"] = False
            valeurs = [m["n"] for m in s["mesures"]]
            self.journal(f"Fin de la série ({raison}) : {len(valeurs)} mesure(s)")
            chemin = s["fichier"]
        if chemin:
            lignes = [""]
            if raison != "série terminée":
                lignes.append(f"Série interrompue ({raison}) après {len(valeurs)} mesure(s) sur {s['voulu']}")
            if valeurs:
                n = len(valeurs)
                moy = sum(valeurs) / n
                ecart = math.sqrt(sum((v - moy) ** 2 for v in valeurs) / (n - 1)) if n > 1 else 0.0
                f = lambda x: f"{x:.2f}".replace(".", ",")  # noqa: E731
                lignes += [f"Nombre de mesures\t{n}", f"Moyenne\t{f(moy)}", f"Ecart-type\t{f(ecart)}",
                           f"Racine de la moyenne\t{f(math.sqrt(moy))}",
                           f"Minimum\t{min(valeurs)}", f"Maximum\t{max(valeurs)}"]
            for ligne in lignes:
                self._ajouter(chemin, ligne)

    def _creer_fichier_radio(self, nombre, commentaire, tube):
        maintenant = datetime.datetime.now()
        chemin = os.path.join(self.dossier, f"radioactivite_{maintenant:%Y-%m-%d_%Hh%Mm%S}.txt")
        lignes = ["Microcosmos - comptage de la radioactivite"] + _date_fichier(maintenant)
        lignes += (commentaire or "").replace("\r\n", "\n").split("\n")
        lignes += ["", f"Série de {nombre} mesures de {DUREE_FENETRE_S} s - tube Geiger {tube}", "",
                   f"MESURE\tHEURE\tIMPULSIONS EN {DUREE_FENETRE_S} s"]
        self._ecrire(chemin, lignes)
        return chemin

    def _fenetre(self, valeurs):
        """Une mesure de 10 s est terminée. valeurs = [GM1, GM2] (ou [n, n] avec MicroCosmosRadioactivite)."""
        t = time.time()
        with self.verrou:
            s = self.serie
            tube = s["tube"] if s and s["en_cours"] else 1
            n = valeurs[tube - 1]
            self.fenetre_n = n
            self.fenetre_instant = t
            if not s or not s["en_cours"]:
                return
            if s["attente"]:                    # fenêtre commencée avant le clic : non comptée
                s["attente"] = False
                return
            heure = datetime.datetime.fromtimestamp(t).strftime("%H:%M:%S")
            s["mesures"].append({"num": len(s["mesures"]) + 1, "heure": heure, "n": n})
            num, chemin, fini = len(s["mesures"]), s["fichier"], len(s["mesures"]) >= s["voulu"]
        if chemin:
            self._ajouter(chemin, f"{num}\t{heure}\t{n}")
        if fini:
            self._terminer_serie("série terminée")

    # ----------------------------------------------------------- fichiers
    @staticmethod
    def _ecrire(chemin, lignes):
        with open(chemin, "w", encoding="cp1252", errors="replace", newline="") as f:
            f.write("\r\n".join(lignes) + "\r\n")

    @staticmethod
    def _ajouter(chemin, ligne):
        with open(chemin, "a", encoding="cp1252", errors="replace", newline="") as f:
            f.write(ligne + "\r\n")

    def fichiers(self):
        resultat = []
        for nom in sorted(os.listdir(self.dossier), reverse=True):
            chemin = os.path.join(self.dossier, nom)
            if os.path.isfile(chemin) and nom.endswith(".txt"):
                st = os.stat(chemin)
                resultat.append({"nom": nom, "taille": st.st_size, "date": st.st_mtime})
        return resultat

    # --------------------------------------------------- boucle de lecture
    def _boucle(self):
        avertissement_ancien = False
        while not self.arret.is_set():
            try:
                ligne = self.liaison.lire_ligne()
            except Exception as e:
                self.journal(f"Erreur de lecture : {e}")
                with self.verrou:
                    self.message = "Liaison avec l'Arduino perdue (câble débranché ?). Reconnectez-vous."
                self._terminer_manip("liaison perdue")
                self._terminer_serie("liaison perdue")
                self.liaison.fermer()
                with self.verrou:
                    self.liaison = None
                    self.connecte = False
                return
            if not ligne:
                continue
            donnees = analyser_ligne(ligne)
            if donnees and donnees[0] == "seconde":
                self.journal(ligne, brut=True)
                self._seconde(*donnees[1])
            elif donnees:
                self.journal(ligne)
                with self.verrou:
                    self.programme = PROG_RADIO
                    self.version = PROG_RADIO
                    self.derniere_donnee = time.time()
                self._fenetre([donnees[1], donnees[1]])
            elif ligne.startswith("#"):
                self.journal(ligne)
                with self.verrou:
                    self.version = ligne.lstrip("# ").split(" - ")[0]
            else:
                self.journal(f"ligne non reconnue : {ligne}")
                if ancien_programme(ligne) and not avertissement_ancien:
                    avertissement_ancien = True
                    with self.verrou:
                        self.message = ("L'Arduino utilise l'ancien programme (DetectionCosmiques 2.0). Téléversez "
                                        "DetectionCosmiques3_0.ino (onglet Fichiers) puis reconnectez-vous.")

    def _seconde(self, seconde, n1, n2, n12):
        valeurs = [n1, n2, n12]
        fenetre = None
        with self.verrou:
            self.programme = PROG_SECONDES
            if not self.version:
                self.version = "MICROCOSMOS 3.0"
            self.derniere_donnee = time.time()
            self.derniere = valeurs
            self.totaux = [a + b for a, b in zip(self.totaux, valeurs)]
            self.secondes += 1
            # radioactivité : regroupement par 10 s
            s = self.serie
            if s and s["en_cours"] and s["attente"]:     # série lancée avant que le programme soit reconnu
                s["attente"] = False
                self._radio_cumul, self._radio_secondes = [0, 0], 0
            self._radio_cumul = [self._radio_cumul[0] + n1, self._radio_cumul[1] + n2]
            self._radio_secondes += 1
            if self._radio_secondes >= DUREE_FENETRE_S:
                fenetre, self._radio_cumul, self._radio_secondes = self._radio_cumul, [0, 0], 0
            # rayons cosmiques : expérience en cours
            m = self.manip
            ligne_fichier = None
            fin_manip = False
            if m:
                m["cumul"] = [a + b for a, b in zip(m["cumul"], valeurs)]
                m["totaux"] = [a + b for a, b in zip(m["totaux"], valeurs)]
                m["n"] += 1
                m["ecoulees"] += 1
                if m["n"] >= m["intervalle"]:
                    t = time.time()
                    heure = datetime.datetime.fromtimestamp(t).strftime("%H:%M:%S")
                    self.historique.append({"t": t, "heure": heure, "valeurs": m["cumul"]})
                    ligne_fichier = heure + "\t" + "\t".join(str(v) for v in m["cumul"])
                    m["cumul"] = [0, 0, 0]
                    m["n"] = 0
                    m["lignes"] += 1
                if ligne_fichier and m["fichier"]:
                    self._ajouter(m["fichier"], ligne_fichier)
                fin_manip = bool(m["duree"] and m["ecoulees"] >= m["duree"])
        if fin_manip:
            self._terminer_manip("durée atteinte")
        if fenetre:
            self._fenetre(fenetre)
