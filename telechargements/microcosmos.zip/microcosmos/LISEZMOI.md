# Microcosmos : rayons cosmiques et radioactivité

Interface dans le navigateur pour le détecteur **Microcosmos** : 1 ou 2 tubes Geiger reliés à un
Arduino Uno. Un seul logiciel pour deux études, choisies par les onglets en haut de la page :

- **Rayons cosmiques** : comptages des deux tubes et de leurs coïncidences, expériences de durée réglable ;
- **Radioactivité** : séries de 30, 60 ou N mesures de 10 s sur un tube, tableau à recopier et histogramme.

Il fonctionne sous Linux, Windows et macOS.

## 1. Programme de l'Arduino (une seule fois)

Le programme recommandé est **`arduino/DetectionCosmiques3_0/DetectionCosmiques3_0.ino`** : il sert
aux deux études. Ouvrez-le avec l'IDE Arduino, choisissez la carte « Arduino Uno » et le bon port,
puis cliquez sur **Téléverser**.

Chaque seconde, il envoie une ligne `D;seconde;impulsions GM1;impulsions GM2;coincidences`
(tube 1 sur l'entrée 2, tube 2 sur l'entrée 3). Une coïncidence est comptée quand les deux tubes
réagissent dans la même fenêtre de 1 ms. Pour la radioactivité, le logiciel additionne les
impulsions du tube choisi par tranches de 10 secondes mesurées par l'Arduino.

Le programme à un seul tube **`arduino/MicroCosmosRadioactivite/`**, qui envoie
`nombre impulsion : N  duree experience : T s` toutes les 10 s, reste accepté pour l'onglet
Radioactivité seulement (tube sur l'entrée 2). Si l'Arduino contient l'ancien programme
DetectionCosmiques 2.0, l'interface le signale.

## Installation par paquet .deb (Linux Mint, Ubuntu, Debian)

Double-cliquez sur `microcosmos_1.2.0_all.deb` puis cliquez sur « Installer le paquet » (mot de passe demandé).
Le paquet installe aussi `python3-serial`, ajoute « Microcosmos » dans le menu (catégorie Éducation ou
Sciences) et donne directement accès aux ports série USB : pas besoin de la commande `usermod`
ni de redémarrer. Les mesures sont rangées dans `Documents/Microcosmos`.
Il remplace la version 1.1.0 si elle est installée.
Pour désinstaller : `sudo apt remove microcosmos`.

## 2. Installer et lancer sans paquet

- **Linux** : `sudo apt install python3-serial` et `sudo usermod -aG dialout $USER` (une seule fois,
  puis redémarrer), puis double-clic sur `lancer.sh` ou `python3 microcosmos.py`.
- **Windows** : installer Python depuis python.org en cochant « Add python.exe to PATH »,
  puis double-clic sur `lancer.bat`.

Le navigateur s'ouvre sur **http://localhost:8001**. Le logiciel du cosmodétecteur utilise le port
8000 : les deux peuvent fonctionner en même temps. Laissez la fenêtre noire ouverte pendant l'utilisation.

Options : `--reseau` (accès depuis les autres appareils du réseau), `--dossier CHEMIN`,
`--port-web 8001`.

## 3. Utilisation

Choisissez le port de l'Arduino puis cliquez sur **Connecter**. Cochez « Simulation » pour essayer
sans détecteur. Une seule mesure à la fois : pendant une expérience « rayons cosmiques », les boutons
de série de l'onglet Radioactivité sont grisés, et inversement.

### Onglet Rayons cosmiques

1. Les trois cartes montrent le total de chaque compteur depuis la dernière remise à zéro et le
   taux en coups/min avec son incertitude (± √N / t). La carte des coïncidences donne aussi le
   nombre de **coïncidences fortuites** attendues (R1 × R2 × 1 ms).
2. **Expérience** : durée (0 = sans limite), intervalle de comptage et commentaire, puis
   « Lancer l'expérience ». Une ligne est écrite à la fin de chaque intervalle dans
   `microcosmos_AAAA-MM-JJ_….txt`, qui se termine par les totaux.
3. **Graphique** : évolution des comptages par intervalle et histogramme comparé à la loi de Poisson.

### Onglet Radioactivité

1. Cliquez sur **30 mesures** (5 min) ou **60 mesures** (10 min), ou tapez un autre nombre puis
   **Lancer**. Choisissez le tube (1 ou 2) avant de lancer. Chaque mesure dure exactement 10 s ;
   la première arrive 10 s après le clic. « Arrêter la série » garde les mesures déjà faites.
2. **Tableau des mesures** : colonnes de 10 mesures (N°, impulsions), faciles à recopier dans le
   cahier. **Imprimer** n'imprime que le tableau.
3. **Histogramme** : nombre de mesures pour chaque nombre d'impulsions. La moyenne et l'écart-type
   ne sont **pas affichés**, pour que les élèves les calculent eux-mêmes.
4. Fichier `radioactivite_AAAA-MM-JJ_….txt` : numéro, heure et nombre d'impulsions de chaque mesure,
   puis, à la fin, le nombre de mesures, la moyenne, l'écart-type, la racine de la moyenne, le
   minimum et le maximum (pour le professeur).

### Onglet Fichiers

Téléchargement des mesures (texte avec tabulations, pour LibreOffice Calc ou Excel) et des deux
programmes Arduino.

## Contenu

- `microcosmos.py` : programme principal (serveur de l'interface web) ;
- `station.py` : lecture des données, expériences, séries, fichiers ;
- `detecteur.py` : liaison série avec l'Arduino et détecteur simulé ;
- `web/index.html` : interface ;
- `arduino/DetectionCosmiques3_0/` et `arduino/MicroCosmosRadioactivite/` : programmes de l'Arduino ;
- `lancer.sh` / `lancer.bat` : lancement par double-clic ;
- `Notice_Microcosmos.pdf` : notice illustrée (installation Windows / Linux sans paquet, programme Arduino, les deux études) ;
- `Notice_Microcosmos_Linux.pdf` : notice pour le paquet .deb ;
- `LICENSE` : licence GNU GPL version 3.

## Auteurs et licence

Microcosmos — détecteur et programmes Arduino : **Cédric Vanden Driessche** ; interface Python-web —
conception et direction du projet : **Cédric Vanden Driessche** (2026), professeur de physique-chimie
au lycée Charles de Gaulle à Caen (cedric.vanden-driessche@ac-normandie.fr) ; développement du code :
Claude (Anthropic), sous sa direction.

Ce programme est un logiciel libre : vous pouvez le redistribuer et le modifier selon les termes
de la Licence publique générale GNU (GPL), version 3 ou toute version ultérieure.
Il est distribué sans aucune garantie. Le texte complet de la licence se trouve dans le fichier `LICENSE`.
