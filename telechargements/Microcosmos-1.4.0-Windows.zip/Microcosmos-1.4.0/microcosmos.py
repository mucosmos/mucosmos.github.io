#!/usr/bin/env python3
# Microcosmos — logiciel installé (Windows, Linux, macOS)
# Détecteur Microcosmos et programmes Arduino : Cédric Vanden Driessche ;
# interface Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
#
# Ce programme est un logiciel libre : vous pouvez le redistribuer et/ou le
# modifier selon les termes de la Licence publique générale GNU (GPL) publiée
# par la Free Software Foundation, version 3 ou (à votre choix) toute version
# ultérieure. Il est distribué SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Microcosmos 1.4.0 — rayons cosmiques, radioactivité, demi-vie du radon, téléversement du programme
dans l'Arduino. Même interface que la version web (https://mucosmos.github.io/microcosmosWeb/), mais :
  - le port série est ouvert par ce programme (pyserial) : tous les navigateurs conviennent, Firefox compris ;
  - les fichiers de mesure sont écrits au fur et à mesure dans un dossier de l'ordinateur.

Lancement :   python3 microcosmos.py      (le navigateur s'ouvre sur http://localhost:8001)

Options :
  --port-web 8001      port de l'interface
  --reseau             interface accessible aux autres appareils du réseau (tablettes…)
  --dossier CHEMIN     dossier des fichiers de mesure (défaut : ./mesures)
  --pas-de-navigateur  ne pas ouvrir le navigateur automatiquement
"""

import argparse
import json
import mimetypes
import os
import secrets
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "1.4.0"
ICI = os.path.dirname(os.path.abspath(__file__))
if getattr(sys, "frozen", False):          # version .exe fabriquée avec PyInstaller
    RESSOURCES = getattr(sys, "_MEIPASS", ICI)
    DOSSIER_PROGRAMME = os.path.dirname(sys.executable)
else:
    RESSOURCES = DOSSIER_PROGRAMME = ICI
WEB = os.path.join(RESSOURCES, "web")

try:
    import serial
    import serial.tools.list_ports
    if not hasattr(serial, "Serial"):
        raise ImportError(f"le module « serial » trouvé ({getattr(serial, '__file__', '?')}) n'est pas pyserial")
    ERREUR_PYSERIAL = None
except Exception as e:  # noqa: BLE001
    serial = None
    ERREUR_PYSERIAL = str(e)

DOSSIER = None
VID_ARDUINO = {0x2341, 0x2A03, 0x1A86, 0x0403, 0x10C4, 0x1B4F, 0x239A}   # Arduino, CH340, FTDI, CP210x…


class ErreurPort(Exception):
    def __init__(self, message, nom="Error"):
        super().__init__(message)
        self.nom = nom


# ------------------------------------------------------------------ port série
class Session:
    """Un port série ouvert pour la page (équivalent d'un SerialPort de Web Serial)."""
    sessions = {}
    verrou = threading.Lock()

    def __init__(self, device, baud):
        if serial is None:
            raise ErreurPort(f"Le module pyserial manque ({ERREUR_PYSERIAL}). Sous Linux : sudo apt install python3-serial ; "
                             "sous Windows : py -m pip install pyserial.")
        with Session.verrou:
            if any(s.device == device for s in Session.sessions.values()):
                raise ErreurPort("Ce port est déjà utilisé par une autre page Microcosmos (fermez l'autre onglet).", "InvalidStateError")
        try:
            self.ser = serial.Serial(device, int(baud), timeout=0.05, write_timeout=3)
        except Exception as e:  # noqa: BLE001
            texte = str(e)
            if "ermission" in texte or "denied" in texte or "Accès refusé" in texte or "PermissionError" in repr(e):
                raise ErreurPort("Accès refusé au port. Fermez l'IDE Arduino ou l'autre logiciel qui l'utilise. Sous Linux : "
                                 "sudo usermod -aG dialout $USER, puis fermez et rouvrez la session (inutile avec le paquet .deb).", "NetworkError")
            if "busy" in texte.lower() or "occupé" in texte:
                raise ErreurPort("Le port est occupé par un autre logiciel (IDE Arduino, moniteur série…).", "NetworkError")
            raise ErreurPort(f"Impossible d'ouvrir {device} : {texte}")
        self.device = device
        self.id = secrets.token_hex(8)
        self.ouverte = True
        with Session.verrou:
            Session.sessions[self.id] = self

    @staticmethod
    def trouver(ident):
        s = Session.sessions.get(ident)
        if not s or not s.ouverte:
            raise ErreurPort("Le port n'est plus ouvert.", "InvalidStateError")
        return s

    def fermer(self):
        self.ouverte = False
        with Session.verrou:
            Session.sessions.pop(self.id, None)
        try:
            self.ser.close()
        except Exception:  # noqa: BLE001
            pass

    @staticmethod
    def tout_fermer():
        for s in list(Session.sessions.values()):
            s.fermer()


def lister_ports():
    if serial is None:
        return []
    ports = []
    for p in sorted(serial.tools.list_ports.comports(), key=lambda p: p.device):
        description = p.description if p.description and p.description != "n/a" else ""
        if p.device.startswith("/dev/ttyS") and not p.vid:      # ports série internes des PC sous Linux
            continue
        ports.append({"device": p.device, "description": description, "vid": p.vid or 0, "pid": p.pid or 0,
                      "arduino": bool(p.vid in VID_ARDUINO)})
    for device in filter(None, os.environ.get("MICROCOSMOS_PORTS_EN_PLUS", "").split(",")):   # essais
        ports.append({"device": device, "description": "port ajouté (essai)", "vid": 0, "pid": 0, "arduino": False})
    ports.sort(key=lambda p: not p["arduino"])
    return ports


# ------------------------------------------------------------------ fichiers
def nom_sur(nom):
    nom = os.path.basename(str(nom)).strip()
    if not nom or nom.startswith(".") or any(c in nom for c in '\\/:*?"<>|'):
        raise ErreurPort("Nom de fichier invalide.", "TypeError")
    return nom


def vers_cp1252(texte):
    texte = texte.replace("τ", "tau").replace("≈", "~").replace("→", "->")
    return texte.encode("cp1252", errors="replace")


def liste_fichiers():
    if not os.path.isdir(DOSSIER):
        return []
    res = []
    for nom in os.listdir(DOSSIER):
        chemin = os.path.join(DOSSIER, nom)
        if os.path.isfile(chemin) and nom.lower().endswith(".txt"):
            res.append({"nom": nom, "date": os.path.getmtime(chemin) * 1000, "taille": os.path.getsize(chemin)})
    return sorted(res, key=lambda f: f["date"], reverse=True)


def ouvrir_dossier():
    os.makedirs(DOSSIER, exist_ok=True)
    if sys.platform.startswith("win"):
        os.startfile(DOSSIER)  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", DOSSIER])
    else:
        subprocess.Popen(["xdg-open", DOSSIER], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ------------------------------------------------------------------ serveur
class Gestionnaire(BaseHTTPRequestHandler):
    server_version = f"Microcosmos/{VERSION}"

    def log_message(self, *args):
        pass

    def _envoyer(self, corps, type_mime, code=200, telechargement=None):
        self.send_response(code)
        self.send_header("Content-Type", type_mime)
        self.send_header("Content-Length", str(len(corps)))
        self.send_header("Cache-Control", "no-store")
        if telechargement:
            self.send_header("Content-Disposition", f"attachment; filename=\"{telechargement}\"")
        self.end_headers()
        self.wfile.write(corps)

    def _json(self, donnees):
        self._envoyer(json.dumps(donnees).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(url.query)
        chemin = urllib.parse.unquote(url.path)
        if chemin in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), encoding="utf-8") as f:
                page = f.read()
            config = json.dumps({"version": VERSION, "dossier": DOSSIER, "pyserial": ERREUR_PYSERIAL is None,
                                 "erreurPyserial": ERREUR_PYSERIAL})
            page = page.replace('<script src="moteur.js"></script>',
                                f'<script>window.MICROCOSMOS_LOCAL={config};</script>\n<script src="pont.js"></script>\n'
                                '<script src="moteur.js"></script>', 1)
            return self._envoyer(page.encode("utf-8"), "text/html; charset=utf-8")
        if chemin == "/serie/ports":
            return self._json(lister_ports())
        if chemin == "/serie/lire":
            return self._lire(params.get("id", [""])[0])
        if chemin == "/fichiers/liste":
            return self._json(liste_fichiers())
        if chemin.startswith("/fichiers/"):
            try:
                nom = nom_sur(chemin[len("/fichiers/"):])
            except ErreurPort:
                return self.send_error(404)
            complet = os.path.join(DOSSIER, nom)
            if os.path.isfile(complet):
                with open(complet, "rb") as f:
                    return self._envoyer(f.read(), "text/plain; charset=windows-1252", telechargement=nom)
            return self.send_error(404)
        # fichiers de l'interface (dossier web)
        relatif = os.path.normpath(chemin.lstrip("/"))
        complet = os.path.join(WEB, relatif)
        if not relatif.startswith("..") and os.path.isfile(complet):
            type_mime = mimetypes.guess_type(complet)[0] or "application/octet-stream"
            if complet.endswith((".ino", ".hex", ".md", ".txt")):
                type_mime = "text/plain; charset=utf-8"
            elif complet.endswith(".js"):
                type_mime = "text/javascript; charset=utf-8"
            with open(complet, "rb") as f:
                return self._envoyer(f.read(), type_mime,
                                     telechargement=os.path.basename(complet) if complet.endswith((".ino", ".hex")) else None)
        self.send_error(404)

    def _lire(self, ident):
        """Flux continu des octets reçus de l'Arduino (lu par la page avec fetch)."""
        try:
            s = Session.trouver(ident)
        except ErreurPort:
            return self.send_error(404)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        try:
            while s.ouverte:
                try:
                    donnees = s.ser.read(max(1, s.ser.in_waiting))
                except Exception:  # noqa: BLE001  (câble débranché, port fermé)
                    break
                if donnees:
                    self.wfile.write(donnees)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            if s.ouverte:        # la page a abandonné la lecture ou le câble est débranché
                s.fermer()
        self.close_connection = True

    def do_POST(self):
        url = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(url.query)
        longueur = int(self.headers.get("Content-Length") or 0)
        corps = self.rfile.read(longueur) if longueur else b""
        try:
            resultat = self._action(url.path, params, corps)
            self._json({"ok": True, "resultat": resultat})
        except ErreurPort as e:
            self._json({"ok": False, "erreur": str(e), "nom": e.nom})
        except Exception as e:  # noqa: BLE001
            self._json({"ok": False, "erreur": f"Erreur inattendue : {e}", "nom": "NetworkError"})

    def _action(self, chemin, params, corps):
        ident = params.get("id", [""])[0]
        if chemin == "/serie/ecrire":
            s = Session.trouver(ident)
            try:
                s.ser.write(corps)
            except Exception as e:  # noqa: BLE001
                s.fermer()
                raise ErreurPort(f"Écriture impossible sur le port : {e}", "NetworkError") from e
            return len(corps)
        d = json.loads(corps or b"{}")
        if chemin == "/serie/ouvrir":
            return Session(d["device"], d.get("baud", 9600)).id
        if chemin == "/serie/signaux":
            s = Session.trouver(ident)
            try:
                if d.get("dtr") is not None:
                    s.ser.dtr = bool(d["dtr"])
                if d.get("rts") is not None:
                    s.ser.rts = bool(d["rts"])
            except Exception:  # noqa: BLE001  (certains adaptateurs n'ont pas ces lignes)
                pass
            return None
        if chemin == "/serie/fermer":
            s = Session.sessions.get(ident)
            if s:
                s.fermer()
            return None
        if chemin == "/fichiers/ecrire":
            nom = nom_sur(d["nom"])
            os.makedirs(DOSSIER, exist_ok=True)
            with open(os.path.join(DOSSIER, nom), "ab" if d.get("mode") == "a" else "wb") as f:
                f.write(vers_cp1252(d.get("texte", "")))
            return None
        if chemin == "/dossier/ouvrir":
            ouvrir_dossier()
            return DOSSIER
        raise ErreurPort("Action inconnue.", "TypeError")


def adresse_locale():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def main():
    global DOSSIER
    parser = argparse.ArgumentParser(description="Microcosmos : rayons cosmiques, radioactivité, demi-vie du radon")
    parser.add_argument("--port-web", type=int, default=8001)
    parser.add_argument("--reseau", action="store_true")
    parser.add_argument("--dossier", default=os.path.join(DOSSIER_PROGRAMME, "mesures"))
    parser.add_argument("--pas-de-navigateur", action="store_true")
    args = parser.parse_args()
    DOSSIER = os.path.abspath(args.dossier)

    if ERREUR_PYSERIAL:
        print(f"ATTENTION : pyserial n'est pas utilisable par {sys.executable}")
        print(f"  Détail : {ERREUR_PYSERIAL}")
        print("  Sous Linux Mint :  sudo apt install python3-serial")
        print("  Ailleurs        :  python3 -m pip install pyserial")
        print("Seule la simulation sera disponible.\n")

    hote = "0.0.0.0" if args.reseau else "127.0.0.1"
    adresse = f"http://localhost:{args.port_web}"
    try:
        serveur = ThreadingHTTPServer((hote, args.port_web), Gestionnaire)
    except OSError as e:
        print(f"Le port {args.port_web} est déjà utilisé ({e}) : le logiciel est sans doute déjà lancé.")
        print(f"Ouverture de l'interface existante : {adresse}")
        if not args.pas_de_navigateur:
            webbrowser.open(adresse)
        time.sleep(3)
        sys.exit(0)
    serveur.daemon_threads = True

    def interrompre(*_):
        raise KeyboardInterrupt
    for nom in ("SIGTERM", "SIGHUP"):
        if hasattr(signal, nom):
            signal.signal(getattr(signal, nom), interrompre)
    print(f"Microcosmos {VERSION} — détecteur et programmes Arduino : Cédric Vanden Driessche ;")
    print("interface Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),")
    print("professeur de physique-chimie au lycée Charles de Gaulle à Caen ;")
    print("développement du code : Claude (Anthropic), sous sa direction.")
    print("Logiciel libre sous licence GNU GPL v3 ou ultérieure.\n")
    print("Microcosmos prêt.")
    print(f"  Interface : {adresse}")
    if args.reseau and adresse_locale():
        print(f"  Depuis un autre appareil du réseau : http://{adresse_locale()}:{args.port_web}")
    print(f"  Fichiers de mesure : {DOSSIER}")
    print("Laissez cette fenêtre ouverte pendant les mesures (Ctrl+C ou fermer la fenêtre pour quitter).")
    if not args.pas_de_navigateur:
        threading.Timer(0.8, lambda: webbrowser.open(adresse)).start()
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        print("\nArrêt du logiciel.")
        Session.tout_fermer()
        serveur.server_close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        if getattr(sys, "frozen", False):
            input("\nErreur. Appuyez sur Entrée pour fermer.")
        raise SystemExit(1)
