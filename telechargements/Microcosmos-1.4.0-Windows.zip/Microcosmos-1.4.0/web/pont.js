/*
 * Microcosmos — pont série du logiciel installé (version Python).
 * Quand la page est servie par microcosmos.py, ce fichier remplace navigator.serial par un accès au port
 * série à travers le programme Python (pyserial). La page fonctionne alors dans tous les navigateurs,
 * Firefox compris, avec exactement les mêmes fonctions que la version web.
 * Copyright (C) 2026 Cédric Vanden Driessche — conception et direction ; code : Claude (Anthropic).
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
"use strict";
(() => {
  if (!window.MICROCOSMOS_LOCAL) return;

  async function appel(chemin, corps, brut) {
    const r = await fetch(chemin, { method: "POST", body: brut ? corps : JSON.stringify(corps || {}),
                                    headers: { "Content-Type": brut ? "application/octet-stream" : "application/json" } });
    const j = await r.json();
    if (!j.ok) { const e = new Error(j.erreur); e.name = j.nom || "NetworkError"; throw e; }
    return j.resultat;
  }

  class PortPont {
    constructor(info) { this.info = info; this.id = null; this.readable = null; this.writable = null; }
    getInfo() { return { usbVendorId: this.info.vid || undefined, usbProductId: this.info.pid || undefined }; }
    async open({ baudRate }) {
      if (this.id) { const e = new Error("Le port est déjà ouvert."); e.name = "InvalidStateError"; throw e; }
      this.id = await appel("/serie/ouvrir", { device: this.info.device, baud: baudRate });
      const id = this.id, port = this;
      let annule = null;
      this.readable = new ReadableStream({
        async start(ctrl) {
          const ac = new AbortController(); annule = () => ac.abort();
          let reponse;
          try { reponse = await fetch(`/serie/lire?id=${id}`, { signal: ac.signal }); }
          catch (e) { ctrl.error(e); return; }
          const lecteur = reponse.body.getReader();
          (async () => {
            try {
              for (;;) {
                const { value, done } = await lecteur.read();
                if (done) break;
                if (value && value.length) ctrl.enqueue(value);
              }
              if (port.id === id) ctrl.error(new Error("Liaison avec l'Arduino perdue (câble débranché ?)."));
              else ctrl.close();
            } catch (e) { try { port.id === id ? ctrl.error(e) : ctrl.close(); } catch (x) {} }
          })();
        },
        cancel() { if (annule) annule(); }
      });
      this.writable = new WritableStream({ write: morceau => appel(`/serie/ecrire?id=${id}`, morceau, true) });
    }
    async setSignals(s) {
      if (!this.id) return;
      await appel(`/serie/signaux?id=${this.id}`, { dtr: s.dataTerminalReady, rts: s.requestToSend });
    }
    async close() {
      const id = this.id; this.id = null;
      if (id) { try { await appel(`/serie/fermer?id=${id}`); } catch (e) {} }
    }
  }

  /* Fenêtre de choix du port (remplace celle du navigateur). */
  function choisirPort() {
    return new Promise((resolve, reject) => {
      const fond = document.createElement("div");
      fond.style.cssText = "position:fixed;inset:0;background:rgba(15,23,34,.45);display:flex;align-items:center;justify-content:center;z-index:50";
      fond.innerHTML = `<div style="background:#fff;border-radius:12px;padding:18px 20px;width:min(460px,92vw);box-shadow:0 10px 40px rgba(0,0,0,.25);font:15px/1.4 system-ui,sans-serif;color:#1b2430">
        <div style="font-weight:650;font-size:17px;margin-bottom:10px">Choisir le port de l'Arduino</div>
        <div id="pontListe" style="display:flex;flex-direction:column;gap:6px;max-height:50vh;overflow:auto"></div>
        <div style="display:flex;gap:8px;margin-top:14px;justify-content:flex-end">
          <button class="btn petit" id="pontMaj">↻ Actualiser</button><button class="btn petit" id="pontAnnuler">Annuler</button></div></div>`;
      document.body.append(fond);
      const fermer = () => { fond.remove(); clearInterval(minuterie); };
      const remplir = async () => {
        let ports = [];
        try { ports = await (await fetch("/serie/ports")).json(); } catch (e) {}
        const l = fond.querySelector("#pontListe"); l.innerHTML = "";
        if (!ports.length) l.innerHTML = `<div style="color:#5f6b7a;padding:10px 0">Aucun port série trouvé. Branchez l'Arduino (avec un câble qui transmet les données) : la liste se met à jour toute seule.</div>`;
        ports.forEach(p => {
          const b = document.createElement("button"); b.className = "btn";
          b.style.cssText = "text-align:left;padding:10px 12px" + (p.arduino ? ";border-color:#0b7285;background:#e3f4f6" : "");
          b.innerHTML = `<b>${p.device}</b>${p.description ? "<br><small style='color:#5f6b7a'>" + p.description + "</small>" : ""}`;
          b.onclick = () => { fermer(); resolve(new PortPont(p)); };
          l.append(b);
        });
      };
      fond.querySelector("#pontMaj").onclick = remplir;
      fond.querySelector("#pontAnnuler").onclick = () => { fermer(); const e = new Error("Aucun port choisi."); e.name = "NotFoundError"; reject(e); };
      const minuterie = setInterval(remplir, 2000);
      remplir();
    });
  }

  const evenements = new EventTarget();
  Object.defineProperty(navigator, "serial", { configurable: true, value: {
    requestPort: choisirPort,
    getPorts: async () => [],
    addEventListener: (t, f) => evenements.addEventListener(t, f),
    removeEventListener: (t, f) => evenements.removeEventListener(t, f),
  }});
})();
