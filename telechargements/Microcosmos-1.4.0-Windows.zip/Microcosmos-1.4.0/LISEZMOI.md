# Microcosmos 1.4.0 : rayons cosmiques, radioactivité, demi-vie du radon

Interface dans le navigateur pour le détecteur **Microcosmos** : 1 ou 2 tubes Geiger reliés à un
Arduino Uno ou Nano. Les études se choisissent par les onglets en haut de la page :

- **Rayons cosmiques** : comptages des deux tubes et de leurs coïncidences, expériences de durée réglable ;
- **Radioactivité** : séries de 30, 60 ou N mesures de 10 s sur un tube, tableau à recopier et histogramme ;
- **Demi-vie (radon)** : bruit de fond, puis décroissance d'un filtre d'aspirateur. La page trace N = f(t) en direct et ajuste N₀·e^(−λt) + fond pour donner T½ ± incertitude. Elle trace aussi ln(N − fond) et la demi-vie apparente par tranche ;
- **Arduino et fichiers** : **téléversement du programme dans l'Arduino en un clic** (sans IDE Arduino), fichiers de mesure, aide.

C'est la même interface que la version web (https://mucosmos.github.io/microcosmosWeb/), avec trois avantages :
- **tous les navigateurs** conviennent, Firefox compris, car c'est le logiciel qui ouvre le port USB ;
- les **fichiers de mesure sont écrits au fur et à mesure** dans un dossier de l'ordinateur ;
- le logiciel **fonctionne sans internet**.

Il fonctionne sous Linux, Windows et macOS.

## 1. Programme de l'Arduino (une seule fois)

Le programme recommandé est **DetectionCosmiques3_0** : il sert à toutes les études. Pour l'envoyer
dans l'Arduino, ouvrez l'onglet **Arduino et fichiers**, cliquez sur **Téléverser dans l'Arduino** et
choisissez le port. L'écriture puis la vérification prennent quelques secondes, et la page se connecte
ensuite toute seule. Cela marche avec les Uno et les Nano, y compris ceux à « ancien bootloader ».
Les sources se trouvent dans `web/arduino/` si vous préférez passer par l'IDE Arduino.

Chaque seconde, il envoie une ligne `D;seconde;impulsions GM1;impulsions GM2;coincidences`
(tube 1 sur l'entrée 2, tube 2 sur l'entrée 3). Une coïncidence est comptée quand les deux tubes
réagissent dans la même fenêtre de 1 ms. Pour la radioactivité, le logiciel additionne les
impulsions du tube choisi par tranches de 10 secondes mesurées par l'Arduino.

Le programme à un seul tube **MicroCosmosRadioactivite**, qui envoie
`nombre impulsion : N  duree experience : T s` toutes les 10 s, reste accepté pour les onglets
Radioactivité et Demi-vie (tube sur l'entrée 2). Si l'Arduino contient l'ancien programme
DetectionCosmiques 2.0, l'interface le signale.

## Installation par paquet .deb (Linux Mint, Ubuntu, Debian)

Double-cliquez sur `microcosmos_1.4.0_all.deb` puis cliquez sur « Installer le paquet » (mot de passe demandé).
Le paquet installe aussi `python3-serial`, ajoute « Microcosmos » dans le menu (catégorie Éducation ou
Sciences) et donne directement accès aux ports série USB : pas besoin de la commande `usermod`
ni de redémarrer. Les mesures sont rangées dans `Documents/Microcosmos`.
Il remplace les versions précédentes si elles sont installées.
Pour désinstaller : `sudo apt remove microcosmos`.

## 2. Installer et lancer sans paquet

- **Linux** : `sudo apt install python3-serial` et `sudo usermod -aG dialout $USER` (une seule fois,
  puis redémarrer), puis double-clic sur `lancer.sh` ou `python3 microcosmos.py`.
- **Windows** : installer Python depuis python.org en cochant « Add python.exe to PATH »,
  puis double-clic sur `lancer.bat`.

Le navigateur s'ouvre sur **http://localhost:8001**. Le logiciel du cosmodétecteur utilise le port
8000 : les deux peuvent fonctionner en même temps. Pendant les mesures, laissez **la fenêtre noire et
l'onglet du navigateur** ouverts : les mesures se font dans la page. Si l'onglet se ferme, la mesure
s'arrête, mais tout ce qui a été mesuré reste dans le fichier.

Options : `--reseau` (accès depuis les autres appareils du réseau), `--dossier CHEMIN`,
`--port-web 8001`.

## Fabriquer un .exe pour Windows (facultatif)

Pour obtenir un seul fichier `Microcosmos.exe`, qui se lance par double-clic **sans installer Python**
sur les autres ordinateurs :

1. Sur **un** PC Windows où Python est installé (python.org, case « Add python.exe to PATH »
   cochée), avec une connexion internet, double-cliquez sur `fabriquer_exe.bat`.
2. Au bout de 1 à 2 minutes, le dossier `dist` s'ouvre : il contient `Microcosmos.exe`.
3. Copiez ce fichier sur les autres PC (clé USB, réseau, bureau…). Les mesures sont rangées dans un
   dossier `mesures` créé à côté de lui. Comme avec `lancer.bat`, une fenêtre noire s'ouvre avec le
   navigateur (http://localhost:8001) : il faut la laisser ouverte.

À la première ouverture, Windows peut afficher « Windows a protégé votre ordinateur » : cliquez sur
« Informations complémentaires » puis « Exécuter quand même ». Certains antivirus se méfient des
programmes fabriqués avec PyInstaller : si le fichier est bloqué, ajoutez une exception ou
utilisez `lancer.bat`. Refaites le `.exe` après chaque mise à jour du logiciel.

## 3. Utilisation

Cliquez sur **Connecter l'Arduino** et choisissez son port dans la liste (l'Arduino apparaît en
premier, sur fond bleuté). Cochez « Simulation » pour essayer sans détecteur, et « accélérée × 60 »
pour faire une mesure de demi-vie de 2 h en 2 min. Une seule mesure à la fois.

### Onglet Rayons cosmiques

1. Les trois cartes montrent le total de chaque compteur depuis la dernière remise à zéro et le
   taux en coups/min avec son incertitude (± √N / t). La carte des coïncidences donne aussi le
   nombre de **coïncidences fortuites** attendues (R1 × R2 × 1 ms).
2. **Expérience** : durée (0 = sans limite), intervalle de comptage et commentaire, puis
   « Lancer l'expérience ». Une ligne est écrite à la fin de chaque intervalle dans
   `microcosmos_AAAA-MM-JJ_….txt`, qui se termine par les totaux.
3. **Graphique** : évolution des comptages par intervalle et histogramme comparé à la loi de Poisson.

### Onglet Radioactivité

1. Cliquez sur **30 mesures** (5 min) ou **60 mesures** (10 min), ou tapez un autre nombre puis
   **Lancer**. Choisissez le tube (1 ou 2) avant de lancer. Chaque mesure dure exactement 10 s ;
   la première arrive 10 s après le clic. « Arrêter la série » garde les mesures déjà faites.
2. **Tableau des mesures** : colonnes de 10 mesures (N°, impulsions), faciles à recopier dans le
   cahier. **Imprimer** n'imprime que le tableau.
3. **Histogramme** : nombre de mesures pour chaque nombre d'impulsions. La moyenne et l'écart-type
   ne sont **pas affichés**, pour que les élèves les calculent eux-mêmes.
4. Fichier `radioactivite_AAAA-MM-JJ_….txt` : numéro, heure et nombre d'impulsions de chaque mesure,
   puis, à la fin, le nombre de mesures, la moyenne, l'écart-type, la racine de la moyenne, le
   minimum et le maximum (pour le professeur).

### Onglet Demi-vie (radon)

1. Mesurez le **bruit de fond** (tube seul, 5 à 20 min) : la valeur s'inscrit dans la case.
2. Aspirez l'air de la pièce 30 à 60 min à travers un filtre à café, posez le filtre sur le tube et
   cliquez sur **Lancer la mesure** (2 h conseillées).
3. La courbe N = f(t) se construit en direct. Vous pouvez régler la durée des classes (30 s à 10 min)
   et l'intervalle d'ajustement (en minutes). Le résultat T½ ± incertitude s'affiche sous la courbe.
4. Le graphique ln(N − fond) et le tableau des demi-vies apparentes par tranche montrent que la
   décroissance n'est pas une exponentielle unique : le plomb 214 alimente le bismuth 214.
5. **Ouvrir un fichier de mesures…** analyse un ancien fichier `radioactivite_…` ou `decroissance_…`.
   **Télécharger le tableau N = f(t)** exporte les classes pour le tableur.

### Onglet Arduino et fichiers

Téléversement du programme dans l'Arduino (ou d'un autre fichier .hex). Liste des fichiers de mesure
du dossier, à télécharger ou à ouvrir avec le bouton **Ouvrir le dossier**. Ce sont des fichiers texte
avec tabulations, pour LibreOffice Calc ou Excel.

## Contenu

- `microcosmos.py` : programme principal. Il sert l'interface, fait le lien avec le port série (pyserial) et écrit les fichiers ;
- `web/` : l'interface, identique à la version web :
  - `index.html` ;
  - `moteur.js` : mesures, simulation, ajustement ;
  - `flasheur.js` : téléversement ;
  - `pont.js` : liaison avec le logiciel ;
- `web/arduino/` : programmes de l'Arduino, en source (.ino) et compilés (.hex) ;
- `fabriquer_exe.bat` et `microcosmos.ico` : fabrication du `.exe` Windows ;
- `lancer.sh` / `lancer.bat` : lancement par double-clic ;
- `Notice_Microcosmos.pdf` : notice illustrée de la version 1.4.0. Elle couvre les trois façons d'installer Microcosmos (site web, paquet Linux, Windows/macOS) et le fonctionnement de chaque onglet ;
- `LICENSE` : licence GNU GPL version 3.

## Auteurs et licence

Microcosmos — détecteur et programmes Arduino : **Cédric Vanden Driessche** ; interface Python-web —
conception et direction du projet : **Cédric Vanden Driessche** (2026), professeur de physique-chimie
au lycée Charles de Gaulle à Caen (cedric.vanden-driessche@ac-normandie.fr) ; développement du code :
Claude (Anthropic), sous sa direction.

Ce programme est un logiciel libre : vous pouvez le redistribuer et le modifier selon les termes
de la Licence publique générale GNU (GPL), version 3 ou toute version ultérieure.
Il est distribué sans aucune garantie. Le texte complet de la licence se trouve dans le fichier `LICENSE`.
