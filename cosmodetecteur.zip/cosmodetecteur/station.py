# Cosmodétecteur — pilotage en Python
# Adaptation du logiciel « Roue Cosmique » [Sciences à l'École, CPPM]
# [Michel Jevaud, Marta Rodo Bordera, 2011] pour le Cosmodétecteur [José Busto] ;
# version Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
#
# Ce programme est un logiciel libre : vous pouvez le redistribuer et/ou le
# modifier selon les termes de la Licence publique générale GNU (GPL) publiée
# par la Free Software Foundation, version 3 ou (à votre choix) toute version
# ultérieure. Il est distribué SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Boucle d'acquisition : lit le boîtier en continu, gère les « manips »
(comptages par intervalle et vie du muon) et écrit les fichiers de mesure
au même format que le logiciel LabVIEW d'origine.
"""

import collections
import datetime
import os
import queue
import threading
import time
import traceback

from boitier import (Boitier, BoitierSimule, ErreurBoitier, NOMS_FONCTIONS,
                     NOMS_VOIES, NOMS_VIEMUON, HORLOGE_NS)

JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]

SEUIL_DEFAUT_MV = 40.0
PAUSE_CYCLE_S = 0.2          # « n millisecondes » = 200 dans le programme d'origine
ECHECS_MAX = 3


def _nombre(x):
    return f"{x:g}" if x != int(x) else str(int(x))


class Erreur(Exception):
    """Erreur à afficher telle quelle à l'utilisateur."""


class Station:
    def __init__(self, dossier_mesures):
        self.dossier = dossier_mesures
        os.makedirs(self.dossier, exist_ok=True)
        self.verrou = threading.RLock()
        self.commandes = queue.Queue()
        self.journal_lignes = collections.deque(maxlen=400)
        self.journal_trames = False
        self.boitier = None
        self.fil = None
        self.arret = threading.Event()
        self._reinitialiser()

    # ------------------------------------------------------------------ état
    def _reinitialiser(self):
        self.connecte = False
        self.port = None
        self.simulation = False
        self.message = ""
        self.voies = [0] * 4
        self.fonctions = [0] * 9
        self.ht_consigne = [0.0] * 4
        self.ht_mesure = [0.0] * 4
        self.seuils = [SEUIL_DEFAUT_MV] * 4
        self.duree_cycle = 0.0
        self.manip = None            # comptages par intervalle
        self.historique = []         # lignes {t, heure, valeurs[13]}
        self.muon = None             # manip vie du muon
        self.muons = []              # événements {t, heure, index, ns}
        self.dernier_muon = [0, 0]

    def journal(self, texte):
        if texte.startswith("->") and not self.journal_trames:
            return
        heure = datetime.datetime.now().strftime("%H:%M:%S")
        self.journal_lignes.append(f"{heure}  {texte}")

    def etat(self):
        with self.verrou:
            maintenant = time.time()
            manip = None
            if self.manip:
                m = self.manip
                manip = {"debut": m["debut"], "fin": m["fin"], "intervalle": m["intervalle"],
                         "prochaine": m["prochaine"], "fichier": os.path.basename(m["fichier"]) if m["fichier"] else None,
                         "lignes": m["lignes"]}
            muon = None
            if self.muon:
                m = self.muon
                muon = {"debut": m["debut"], "fin": m["fin"],
                        "fichier": os.path.basename(m["fichier"]) if m["fichier"] else None,
                        "evenements": m["evenements"]}
            return {
                "connecte": self.connecte, "port": self.port, "simulation": self.simulation,
                "message": self.message, "heure": maintenant,
                "voies": self.voies, "fonctions": self.fonctions,
                "noms_voies": NOMS_VOIES, "noms_fonctions": NOMS_FONCTIONS, "noms_viemuon": NOMS_VIEMUON,
                "ht_consigne": self.ht_consigne, "ht_mesure": [round(v, 1) for v in self.ht_mesure],
                "seuils": self.seuils, "duree_cycle": round(self.duree_cycle, 3),
                "manip": manip, "muon": muon, "dernier_muon": self.dernier_muon,
                "n_historique": len(self.historique), "n_muons": len(self.muons),
                "journal_trames": self.journal_trames,
            }

    def historique_depuis(self, i_hist, i_muon):
        with self.verrou:
            return {"historique": self.historique[i_hist:], "muons": self.muons[i_muon:],
                    "n_historique": len(self.historique), "n_muons": len(self.muons)}

    # --------------------------------------------------------- connexion
    def connecter(self, port, simulation=False):
        self.deconnecter()
        if simulation:
            boitier = Boitier(BoitierSimule(), self.journal)
            nom = "simulation"
        else:
            if not port:
                raise Erreur("Choisissez un port série.")
            try:
                boitier = Boitier.ouvrir(port, self.journal)
            except Exception as e:
                if "ermission" in str(e):
                    raise Erreur(f"Accès refusé au port {port}. Sous Linux, tapez dans un terminal :  "
                                 "sudo usermod -aG dialout $USER  puis fermez la session et reconnectez-vous.")
                raise Erreur(f"Impossible d'ouvrir {port} : {e}")
            nom = port
        if not simulation and not boitier.synchroniser():
            # Comme « choisir un autre port puis revenir » avec l'ancien logiciel : on ferme et on rouvre,
            # en essayant aussi d'autres états des lignes DTR / RTS (certains adaptateurs ou boîtiers
            # réagissent à ces lignes à l'ouverture du port), avec une attente plus longue.
            essais = [(True, True), (False, False), (True, False), (False, True)]
            ok = False
            for dtr, rts in essais:
                boitier.fermer()
                time.sleep(1.0)
                self.journal(f"Réouverture du port (DTR={'oui' if dtr else 'non'}, RTS={'oui' if rts else 'non'})")
                try:
                    boitier = Boitier.ouvrir(port, self.journal, dtr=dtr, rts=rts, attente=2.0)
                except Exception as e:
                    raise Erreur(f"Impossible de rouvrir {port} : {e}")
                if boitier.synchroniser(decalages=2):
                    self.journal(f"Le boîtier répond avec DTR={'oui' if dtr else 'non'}, RTS={'oui' if rts else 'non'}")
                    ok = True
                    break
            if not ok:
                boitier.fermer()
                raise Erreur(f"Le boîtier ne répond pas correctement sur {nom}. Éteignez puis rallumez le boîtier "
                             "(ou débranchez puis rebranchez le câble USB), attendez quelques secondes et cliquez "
                             "de nouveau sur « Connecter ». Si cela persiste, regardez l'onglet Journal.")
        try:
            self.journal(f"Connexion à {nom} : seuils à {_nombre(SEUIL_DEFAUT_MV)} mV, HT à 0 V, remise à zéro")
            for v in range(4):
                boitier.programmer_seuil(v, SEUIL_DEFAUT_MV)
            for v in range(4):
                boitier.programmer_ht(v, 0)
            boitier.raz_tout()
        except ErreurBoitier as e:
            boitier.fermer()
            raise Erreur(f"Le boîtier ne répond pas sur {nom} ({e}). "
                         "Vérifiez le câble, l'alimentation du boîtier et le choix du port.")
        with self.verrou:
            self._reinitialiser()
            self.boitier = boitier
            self.connecte = True
            self.port = nom
            self.simulation = simulation
        self.arret.clear()
        self.fil = threading.Thread(target=self._boucle, daemon=True)
        self.fil.start()

    def deconnecter(self, couper_ht=True):
        if not self.boitier:
            return
        self.arret.set()
        if self.fil and self.fil is not threading.current_thread():
            self.fil.join(timeout=10)
        self._terminer_manip("déconnexion")
        self._terminer_muon("déconnexion")
        if couper_ht:
            try:
                for v in range(4):
                    self.boitier.programmer_ht(v, 0)
                self.journal("HT remises à 0 V")
            except Exception as e:
                self.journal(f"Impossible de remettre les HT à 0 : {e}")
        self.boitier.fermer()
        with self.verrou:
            self.boitier = None
            self.connecte = False

    # ---------------------------------------------------- commandes (UI)
    def _executer(self, fonction, *args):
        """Fait exécuter une action par le fil d'acquisition et attend le résultat."""
        if not self.connecte:
            raise Erreur("Le boîtier n'est pas connecté.")
        fini = threading.Event()
        resultat = {}
        self.commandes.put((fonction, args, fini, resultat))
        if not fini.wait(15):
            raise Erreur("Le boîtier ne répond pas.")
        if "erreur" in resultat:
            raise resultat["erreur"]
        return resultat.get("valeur")

    def _verifier_reglages_libres(self):
        if self.manip or self.muon:
            raise Erreur("Une manip est en cours : arrêtez-la avant de modifier les réglages.")

    def regler_ht(self, voie, volts):
        volts = float(volts)
        if not 0 <= volts <= 1500:
            raise Erreur("La consigne HT doit être comprise entre 0 et 1500 V.")
        self._verifier_reglages_libres()

        def action():
            self.boitier.programmer_ht(voie, volts)
            self.ht_consigne[voie] = volts
            self.journal(f"HT {NOMS_VOIES[voie]} = {_nombre(volts)} V")
        self._executer(action)

    def regler_seuil(self, voie, mv):
        mv = float(mv)
        if not 0 <= mv <= 330:
            raise Erreur("Le seuil doit être compris entre 0 et 330 mV.")
        self._verifier_reglages_libres()

        def action():
            self.boitier.programmer_seuil(voie, mv)
            self.seuils[voie] = mv
            self.journal(f"Seuil {NOMS_VOIES[voie]} = {_nombre(mv)} mV")
        self._executer(action)

    def raz(self, quoi, index=None):
        def action():
            b = self.boitier
            if quoi == "voie":
                b.raz_voie(index); self.voies[index] = 0
            elif quoi == "fonction":
                b.raz_fonction(index); self.fonctions[index] = 0
            elif quoi == "muon":
                b.raz_viemuon(index); self.dernier_muon[index] = 0
            elif quoi == "tout":
                b.raz_tout(); self.voies = [0] * 4; self.fonctions = [0] * 9; self.dernier_muon = [0, 0]
        self._executer(action)

    # ------------------------------------------------------------- manips
    def lancer_manip(self, duree_s, intervalle_s, fichier, commentaire):
        if self.manip:
            raise Erreur("Une manip de comptage est déjà en cours.")
        intervalle_s = float(intervalle_s)
        duree_s = float(duree_s)
        if intervalle_s < 1:
            raise Erreur("L'intervalle doit être d'au moins 1 seconde.")
        if duree_s and duree_s < intervalle_s:
            raise Erreur("La durée de manip doit être plus longue que l'intervalle.")

        def action():
            for v in range(4):
                self.boitier.raz_voie(v)
            for f in range(9):
                self.boitier.raz_fonction(f)
            debut = time.time()
            chemin = self._creer_fichier("comptage", commentaire, False) if fichier else None
            with self.verrou:
                self.voies = [0] * 4
                self.fonctions = [0] * 9
                self.historique = []
                self.manip = {"debut": debut, "fin": debut + duree_s if duree_s else None,
                              "intervalle": intervalle_s, "prochaine": debut + intervalle_s,
                              "fichier": chemin, "lignes": 0}
            self.journal("Manip de comptage lancée" + (f" (fichier {os.path.basename(chemin)})" if chemin else ""))
        self._executer(action)

    def arreter_manip(self):
        self._terminer_manip("arrêt demandé")

    def lancer_muon(self, duree_s, fichier, commentaire):
        if self.muon:
            raise Erreur("Une manip vie du muon est déjà en cours.")
        duree_s = float(duree_s)

        def action():
            for m in range(2):
                self.boitier.raz_viemuon(m)
            debut = time.time()
            chemin = self._creer_fichier("viemuon", commentaire, True) if fichier else None
            with self.verrou:
                self.muons = []
                self.dernier_muon = [0, 0]
                self.muon = {"debut": debut, "fin": debut + duree_s if duree_s else None,
                             "fichier": chemin, "evenements": 0}
            self.journal("Manip vie du muon lancée" + (f" (fichier {os.path.basename(chemin)})" if chemin else ""))
        self._executer(action)

    def arreter_muon(self):
        self._terminer_muon("arrêt demandé")

    def effacer_muons(self):
        with self.verrou:
            self.muons = []

    def _terminer_manip(self, raison):
        with self.verrou:
            if self.manip:
                self.journal(f"Fin de la manip de comptage ({raison}), {self.manip['lignes']} intervalles")
                self.manip = None

    def _terminer_muon(self, raison):
        with self.verrou:
            if self.muon:
                self.journal(f"Fin de la manip vie du muon ({raison}), {self.muon['evenements']} événements")
                self.muon = None

    # ------------------------------------------------------------ fichiers
    def _creer_fichier(self, prefixe, commentaire, viemuon):
        maintenant = datetime.datetime.now()
        nom = f"{prefixe}_{maintenant:%Y-%m-%d_%Hh%Mm%S}.txt"
        chemin = os.path.join(self.dossier, nom)
        lignes = []
        if viemuon:
            lignes.append("Vie du muon")
        lignes.append(f"Date du: {JOURS[maintenant.weekday()]} {maintenant.day} {MOIS[maintenant.month - 1]} {maintenant.year}")
        lignes.append(f"Heure:{maintenant:%H:%M}")
        lignes += (commentaire or "").replace("\r\n", "\n").split("\n")
        lignes.append("")
        h = [_nombre(v) for v in self.ht_consigne]
        lignes.append(f"HT PM1: {h[0]}V\tHT PM2:{h[1]}V\tHT PM3:{h[2]}V\tHT PM4: {h[3]}V")
        lignes.append("\t".join(f"Seuil PM{i + 1}: {_nombre(s)}mV" for i, s in enumerate(self.seuils)))
        lignes.append("")
        if viemuon:
            lignes.append("HEURE\tVIE DU MUON 1 (ns) ")
        else:
            entetes = ["HEURE", "COMPTAGE VOIE 1   ", "COMPTAGE VOIE 2", "COMPTAGE VOIE 3   ", "COMPTAGE VOIE 4"]
            entetes += [f"COMPTAGE FONCTION {n}" for n in NOMS_FONCTIONS]
            lignes.append("\t".join(entetes))
        with open(chemin, "w", encoding="cp1252", errors="replace", newline="") as f:
            f.write("\r\n".join(lignes) + "\r\n")
        return chemin

    @staticmethod
    def _ajouter(chemin, ligne):
        with open(chemin, "a", encoding="cp1252", errors="replace", newline="") as f:
            f.write(ligne + "\r\n")

    def fichiers(self):
        resultat = []
        for nom in sorted(os.listdir(self.dossier), reverse=True):
            chemin = os.path.join(self.dossier, nom)
            if os.path.isfile(chemin) and nom.endswith(".txt"):
                st = os.stat(chemin)
                resultat.append({"nom": nom, "taille": st.st_size, "date": st.st_mtime})
        return resultat

    # ----------------------------------------------------- boucle principale
    def _boucle(self):
        echecs = 0
        while not self.arret.is_set():
            debut_cycle = time.monotonic()
            try:
                self._traiter_commandes()
                self._cycle()
                echecs = 0
            except ErreurBoitier as e:
                echecs += 1
                self.journal(f"Erreur de communication : {e}")
                try:
                    self.boitier.synchroniser()
                except Exception:
                    pass
                if echecs >= ECHECS_MAX:
                    with self.verrou:
                        self.message = "Le boîtier ne répond plus : vérifiez le câble et l'alimentation, puis reconnectez."
                    self._perte_connexion()
                    return
            except Exception:
                self.journal("Erreur interne : " + traceback.format_exc().splitlines()[-1])
            self.duree_cycle = time.monotonic() - debut_cycle
            pause = PAUSE_CYCLE_S
            m = self.manip
            if m:
                # se caler exactement sur la fin de l'intervalle si elle tombe avant le prochain cycle
                reste = m["prochaine"] - time.time()
                if reste < PAUSE_CYCLE_S + self.duree_cycle:
                    pause = max(0.0, reste)
            self.arret.wait(pause)
        self._traiter_commandes()

    def _perte_connexion(self):
        self._terminer_manip("perte de connexion")
        self._terminer_muon("perte de connexion")
        if self.boitier:
            self.boitier.fermer()
        with self.verrou:
            self.boitier = None
            self.connecte = False
        while not self.commandes.empty():
            _, _, fini, resultat = self.commandes.get_nowait()
            resultat["erreur"] = Erreur("Le boîtier ne répond plus.")
            fini.set()

    def _traiter_commandes(self):
        while True:
            try:
                fonction, args, fini, resultat = self.commandes.get_nowait()
            except queue.Empty:
                return
            try:
                resultat["valeur"] = fonction(*args)
            except ErreurBoitier as e:
                resultat["erreur"] = Erreur(f"Le boîtier ne répond pas : {e}")
            except Exception as e:
                resultat["erreur"] = e
            fini.set()

    def _cycle(self):
        b = self.boitier
        maintenant = time.time()
        fin_intervalle = bool(self.manip and maintenant >= self.manip["prochaine"])

        if fin_intervalle:
            # lecture puis remise à zéro immédiate de chaque compteur (temps mort minimal)
            voies, fonctions = [], []
            for v in range(4):
                voies.append(b.lire_voie(v)); b.raz_voie(v)
            for f in range(9):
                fonctions.append(b.lire_fonction(f)); b.raz_fonction(f)
            self._enregistrer_intervalle(voies, fonctions)
        else:
            voies = [b.lire_voie(v) for v in range(4)]
            fonctions = [b.lire_fonction(f) for f in range(9)]
            with self.verrou:
                self.voies, self.fonctions = voies, fonctions

        # seule la méthode « vie du muon 1 » (START = STOP = PM4) est utilisée ;
        brut = b.lire_viemuon_brut(0)
        if brut:
            b.raz_viemuon(0)
            self._evenement_muon(0, brut * HORLOGE_NS)

        mesures = [b.lire_ht(v) for v in range(4)]
        with self.verrou:
            self.ht_mesure = mesures

        maintenant = time.time()
        if self.manip and self.manip["fin"] and maintenant >= self.manip["fin"]:
            self._terminer_manip("durée atteinte")
        if self.muon and self.muon["fin"] and maintenant >= self.muon["fin"]:
            self._terminer_muon("durée atteinte")

    def _enregistrer_intervalle(self, voies, fonctions):
        t = time.time()
        heure = datetime.datetime.fromtimestamp(t).strftime("%H:%M:%S")
        valeurs = voies + fonctions
        with self.verrou:
            m = self.manip
            self.voies, self.fonctions = [0] * 4, [0] * 9
            self.historique.append({"t": t, "heure": heure, "valeurs": valeurs})
            m["lignes"] += 1
            m["prochaine"] += m["intervalle"]
            if m["prochaine"] < t:          # rattrapage si l'ordinateur a pris du retard
                m["prochaine"] = t + m["intervalle"]
            chemin = m["fichier"]
        if chemin:
            self._ajouter(chemin, heure + "\t" + "\t".join(str(v) for v in valeurs))

    def _evenement_muon(self, index, ns):
        t = time.time()
        heure = datetime.datetime.fromtimestamp(t).strftime("%H:%M:%S")
        with self.verrou:
            self.dernier_muon[index] = ns
            self.muons.append({"t": t, "heure": heure, "index": index, "ns": ns})
            chemin = None
            if self.muon:
                self.muon["evenements"] += 1
                chemin = self.muon["fichier"]
        if chemin:
            self._ajouter(chemin, f"{heure}\t{ns}")
