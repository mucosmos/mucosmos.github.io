# Protocole du boîtier du cosmodétecteur

Retrouvé dans les sous-VI de `KA2.llb` intégrés à `Roue Cosmique.exe` (constantes, libellés,
connecteurs) et dans le diagramme de `_IHM_Programme Principal.vi`.

## Liaison série

9600 bauds, 8 bits de données, sans parité, 1 bit de stop, sans contrôle de flux
(`Initialisation port serie.vi`).

## Trame

Chaque commande envoie 6 octets et attend 6 octets en réponse (délai maximal : 3 s,
`envoi message.vi`) :

| octet | 0 | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|---|
| contenu | `#` (0x23) | Commande | Data 1 | Data 2 | Data 3 | `?` (0x3F) |

Pour une lecture, la valeur renvoyée vaut `réponse[3] × 256 + réponse[4]`.

## Commandes

| Code | Sous-VI d'origine | Data 1 | Data 2 / Data 3 |
|---|---|---|---|
| 0 | programmation seuil DAC | voie 0–3 | code DAC 12 bits (poids fort / faible) |
| 1 | lecture compteur voie | voie 0–3 | — |
| 2 | RAZ compteur voie | voie 0–3 | — |
| 3 | lecture compteur fonction | fonction 0–8 | — |
| 4 | RAZ compteur fonction | fonction 0–8 | — |
| 5 | lecture compteur vie du muon | 0 ou 1 | — |
| 6 | RAZ compteur vie du muon | 0 ou 1 | — |
| 7 | programmation HT PM | voie 0–3 | code DAC 12 bits |
| 8 | lecture HT PM | voie 0–3 | — |

Voies : 0 = PM1 … 3 = PM4.
Fonctions : 0 PM1×PM2, 1 PM1×PM3, 2 PM1×PM4, 3 PM2×PM3, 4 PM2×PM4, 5 PM3×PM4,
6 PM1×PM2×PM3, 7 PM1×PM2×PM3×PM4, 8 PM1×PM2*×PM3* (anticoïncidence).
Vie du muon : 0 = START PM4 / STOP PM4 ; 1 = START PM4×PM1 / STOP PM4×PM1*×PM2*.

## Conversions

- **Seuil** : `code = arrondi(seuil_mV × 10 / 3300 × 4095)` (ampli d'entrée de gain 10, DAC 3,3 V).
  Exemple tiré du VI : 100 mV → 1241 → trame `23 00 00 04 D9 3F`.
- **Consigne HT** : `commande = HT_V × 5 / 1500` (limitée à 5 V), puis `code = arrondi(commande / 6,6 × 4095)`.
- **Lecture HT** : `HT_V = code × 3,3 / 4096 × 485`.
- **Vie du muon** : `durée_ns = valeur × 8` (horloge du boîtier à 8 ns).

## Fonctionnement du logiciel d'origine

- À l'initialisation : seuils à 40 mV, HT à 0 V, remise à zéro de tous les compteurs.
- Boucle de lecture toutes les 200 ms : 4 compteurs de voie, 9 compteurs de fonction,
  2 compteurs de vie du muon (remis à zéro après lecture), 4 lectures HT.
- Pendant une manip, à chaque intervalle : une ligne écrite dans le fichier, puis remise à zéro des compteurs.

## Points non vérifiés sur le matériel

L'ordre des octets Data dans la trame est déduit d'une réponse enregistrée dans le VI de seuil
(`23 00 00 04 D9 3F`). Le code de commande du seuil (0) vient aussi de cette trame.
