# Cosmodétecteur : pilotage en Python

Ce programme remplace le logiciel LabVIEW « Roue Cosmique » (CPPM / Sciences à l'École, 2011).
Il pilote le boîtier électronique (haute tension des PM, seuils, compteurs, vie du muon) et
s'utilise dans un navigateur web. Il fonctionne sous Linux (Linux Mint, Ubuntu…), Windows et macOS.

## Installation sous Linux Mint (une seule fois)

1. Copiez le dossier `cosmodetecteur` où vous voulez, par exemple dans votre dossier personnel.
2. Ouvrez un terminal et tapez :

   ```
   sudo apt install python3-serial
   sudo usermod -aG dialout $USER
   ```

   La 2ᵉ commande donne le droit d'utiliser le port série. **Fermez ensuite la session
   (ou redémarrez)** pour qu'elle prenne effet.
3. Si le boîtier est relié par un adaptateur USB-série, branchez-le puis tapez `sudo dmesg | tail` :
   une ligne du type `ttyUSB0` ou `ttyACM0` doit apparaître. C'est le nom du port à choisir.

## Lancement

Dans un terminal, depuis le dossier du programme :

```
python3 cosmodetecteur.py
```

ou double-cliquez sur `lancer.sh` (choisir « Lancer dans un terminal »).
Le navigateur s'ouvre sur http://localhost:8000. **Laissez la fenêtre du terminal ouverte** pendant
l'utilisation : la fermer (ou Ctrl+C) arrête le logiciel et remet les HT à 0 V.

Pour créer une icône dans le menu, copiez `cosmodetecteur.desktop` dans `~/.local/share/applications/`
après avoir corrigé le chemin indiqué dans la ligne `Exec=`.

Options utiles :

| Option | Effet |
|---|---|
| `--reseau` | l'interface est accessible depuis les autres ordinateurs ou tablettes de la salle (adresse affichée au démarrage) |
| `--dossier CHEMIN` | dossier des fichiers de mesure (par défaut `mesures/` à côté du programme) |
| `--port-web 8080` | change le port de l'interface web |

## Utilisation

1. Choisissez le port série en haut à droite, puis **Connecter**. À la connexion, comme l'ancien
   logiciel, les seuils sont mis à 40 mV, les HT à 0 V et tous les compteurs à zéro.
   Cochez **Simulation** pour essayer le logiciel sans détecteur.
2. **Haute tension** : réglez la consigne de chaque PM (0 à 1500 V), puis cliquez sur *Appliquer*.
   La jauge montre la tension lue par le boîtier.
3. **Comptages** : seuils par voie, compteurs, et lancement d'une manip (durée, intervalle, commentaire).
   À chaque intervalle, une ligne est ajoutée au fichier et les compteurs repartent de zéro.
   Le graphique montre l'évolution et l'histogramme des comptages comparé à la loi de Poisson.
4. **Coïncidences** : les 9 compteurs de fonctions (PM1×PM2, …, anticoïncidence PM1×PM2*×PM3*).
5. **Vie du muon** : temps START→STOP, histogramme et ajustement exponentiel de la durée de vie.
6. **Fichiers** : téléchargement des mesures. Le format est identique à celui de l'ancien logiciel
   (texte avec tabulations, encodage Windows), ce qui permet de garder vos feuilles de calcul.
7. **Journal** : messages du programme ; la case « Afficher les trames » montre les octets échangés
   avec le boîtier (utile en cas de problème).

Durée de manip à 0 h 0 min 0 s = sans limite (jusqu'à « Arrêter »).

## Contenu

- `cosmodetecteur.py` : programme principal (serveur de l'interface web) ;
- `station.py` : boucle d'acquisition, manips, fichiers ;
- `boitier.py` : protocole du boîtier et simulateur ;
- `web/index.html` : interface ;
- `lancer.sh` / `lancer.bat` : lancement par double-clic sous Linux / Windows ;
- `PROTOCOLE.md` : description du protocole retrouvé dans le logiciel d'origine ;
- `LICENSE` : texte de la licence GNU GPL version 3.

## Auteurs et licence

Adaptation du logiciel **Roue Cosmique** [Sciences à l'École, CPPM] [Michel Jevaud, Marta Rodo
Bordera, 2011] pour le Cosmodétecteur [José Busto] ; version Python-web —
conception et direction du projet : **Cédric Vanden Driessche** (2026), professeur de physique-chimie
au lycée Charles de Gaulle à Caen (cedric.vanden-driessche@ac-normandie.fr) ; développement du code :
Claude (Anthropic), sous sa direction.

Ce programme est un logiciel libre : vous pouvez le redistribuer et le modifier selon les termes
de la Licence publique générale GNU (GPL), version 3 ou toute version ultérieure.
Il est distribué sans aucune garantie. Le texte complet de la licence se trouve dans le fichier `LICENSE`.
