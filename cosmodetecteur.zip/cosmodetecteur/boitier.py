# Cosmodétecteur — pilotage en Python
# Adaptation du logiciel « Roue Cosmique » [Sciences à l'École, CPPM]
# [Michel Jevaud, Marta Rodo Bordera, 2011] pour le Cosmodétecteur [José Busto] ;
# version Python-web — conception et direction du projet : Cédric Vanden Driessche (2026),
# professeur de physique-chimie au lycée Charles de Gaulle à Caen
# (cedric.vanden-driessche@ac-normandie.fr) ; développement du code : Claude (Anthropic),
# sous sa direction.
#
# Copyright (C) 2026 Cédric Vanden Driessche
#
# Ce programme est un logiciel libre : vous pouvez le redistribuer et/ou le
# modifier selon les termes de la Licence publique générale GNU (GPL) publiée
# par la Free Software Foundation, version 3 ou (à votre choix) toute version
# ultérieure. Il est distribué SANS AUCUNE GARANTIE ; voir le fichier LICENSE.
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Communication avec le boîtier électronique du cosmodétecteur (roue cosmique CPPM).

Protocole retrouvé à partir des sous-VI LabVIEW de « KA2.llb » (programme
« Roue Cosmique », M. Jevaud / M. Rodo Bordera, CPPM 2011) :

  * liaison série 9600 bauds, 8 bits, sans parité, 1 bit de stop, sans contrôle de flux ;
  * chaque échange = 6 octets envoyés puis 6 octets reçus :
        '#'  Commande  Data1  Data2  Data3  '?'
    Data1 = numéro de voie / de fonction (0 = PM1 ...), Data2/Data3 = valeur
    sur 12 ou 16 bits (poids fort, poids faible) ;
  * la réponse a la même forme ; pour une lecture, la valeur est
    réponse[3] * 256 + réponse[4].
"""

import math
import random
import threading
import time

# --- Codes de commande -------------------------------------------------------
CMD_SEUIL = 0          # programmation seuil DAC          (Data1 = voie)
CMD_LIRE_VOIE = 1      # lecture compteur voie            (Data1 = voie 0..3)
CMD_RAZ_VOIE = 2       # remise à zéro compteur voie
CMD_LIRE_FONCTION = 3  # lecture compteur fonction        (Data1 = fonction 0..8)
CMD_RAZ_FONCTION = 4   # remise à zéro compteur fonction
CMD_LIRE_VIEMUON = 5   # lecture compteur vie du muon     (Data1 = 0 ou 1)
CMD_RAZ_VIEMUON = 6    # remise à zéro compteur vie du muon
CMD_ECRIRE_HT = 7      # programmation haute tension      (Data1 = voie)
CMD_LIRE_HT = 8        # lecture haute tension            (Data1 = voie)

NOMS_VOIES = ["PM1", "PM2", "PM3", "PM4"]
NOMS_FONCTIONS = ["PM1xPM2", "PM1xPM3", "PM1xPM4", "PM2xPM3", "PM2xPM4",
                  "PM3xPM4", "PM1xPM2xPM3", "PM1xPM2xPM3xPM4", "PM1xPM2*xPM3*"]
NOMS_VIEMUON = ["START = PM4 / STOP = PM4",
                "START = PM4xPM1 / STOP = PM4 x PM1* x PM2*"]

# --- Constantes de conversion (valeurs lues dans les VI d'origine) ----------
GAIN_AMPLI_ENTREE = 10.0      # seuil après ampli = seuil d'entrée x 10
DAC_MAX_MV = 3300.0           # DAC 12 bits, 3,3 V
DAC_MAX_CODE = 4095
HT_MAX_VOLTS = 1500.0         # consigne 0..1500 V  ->  commande 0..5 V
HT_COMMANDE_MAX = 5.0         # « Limitation 5V »
HT_DAC_PLEINE_ECHELLE = 6.6   # « Valeur tension maximum »
ADC_MAX_VOLTS = 3.3           # ADC 12 bits, 3,3 V
ADC_BITS = 12
HT_FACTEUR_LECTURE = 485      # HT (V) = tension ADC x 485
HORLOGE_NS = 8                # « Horloge KA2 en ns »

TIMEOUT_S = 3.0               # « Timeout sur message » : 3000 ms


class ErreurBoitier(Exception):
    pass


def code_seuil(seuil_mv):
    code = round(seuil_mv * GAIN_AMPLI_ENTREE / DAC_MAX_MV * DAC_MAX_CODE)
    return max(0, min(DAC_MAX_CODE, int(code)))


def code_ht(volts):
    commande = max(0.0, volts) * HT_COMMANDE_MAX / HT_MAX_VOLTS
    commande = min(commande, HT_COMMANDE_MAX)
    code = round(commande / HT_DAC_PLEINE_ECHELLE * DAC_MAX_CODE)
    return max(0, min(DAC_MAX_CODE, int(code)))


def volts_depuis_adc_ht(code):
    return code * ADC_MAX_VOLTS / (2 ** ADC_BITS) * HT_FACTEUR_LECTURE


def trame(commande, data1=0, data2=0, data3=0):
    return bytes([0x23, commande & 0xFF, data1 & 0xFF, data2 & 0xFF, data3 & 0xFF, 0x3F])


class Boitier:
    """Pilote du boîtier. `port` est un objet de type serial.Serial (ou le simulateur)."""

    def __init__(self, port, journal=None):
        self.port = port
        self.journal = journal or (lambda texte: None)
        self.verrou = threading.Lock()

    @classmethod
    def ouvrir(cls, nom_port, journal=None, dtr=True, rts=True, attente=0.2):
        """Ouvre le port à 9600 bauds 8N1. dtr / rts : état des lignes de contrôle à l'ouverture."""
        import serial  # pyserial
        port = serial.Serial()
        port.port = nom_port
        port.baudrate, port.bytesize, port.parity, port.stopbits = 9600, 8, "N", 1
        port.xonxoff = port.rtscts = port.dsrdtr = False
        port.timeout, port.write_timeout = 0.1, TIMEOUT_S   # lectures courtes, délai géré par echange
        port.dtr, port.rts = dtr, rts                         # appliqués dès l'ouverture
        port.open()
        time.sleep(attente)
        port.reset_input_buffer()
        return cls(port, journal)

    def fermer(self):
        try:
            self.port.close()
        except Exception:
            pass

    # -- échange élémentaire --------------------------------------------------
    def _purger(self, pause=0.3):
        """Attend la fin d'une éventuelle réponse en retard et vide le tampon de réception."""
        time.sleep(pause)
        try:
            n = self.port.in_waiting
            restes = self.port.read(n) if n else b""
            self.port.reset_input_buffer()
        except Exception:
            restes = b""
        if restes:
            self.journal(f"octets en trop jetés : {restes.hex(' ')}")

    def _echange_brut(self, message, timeout=None):
        """Envoie une trame et renvoie ce qui a été reçu (6 octets attendus), sans contrôle."""
        en_attente = self.port.in_waiting
        if en_attente:
            restes = self.port.read(en_attente)
            self.journal(f"attention : {len(restes)} octets en attente avant l'envoi ({restes.hex(' ')})")
        self.port.write(message)
        reponse = b""
        limite = time.monotonic() + (timeout or TIMEOUT_S)
        while len(reponse) < 6 and time.monotonic() < limite:
            morceau = self.port.read(6 - len(reponse))
            if morceau:
                reponse += morceau
        self.journal(f"-> {message.hex(' ')}   <- {reponse.hex(' ') if reponse else '(rien)'}")
        return reponse

    @staticmethod
    def _reponse_valide(reponse):
        return len(reponse) == 6 and reponse[0] == 0x23 and reponse[5] == 0x3F

    def echange(self, commande, data1=0, data2=0, data3=0, essais=3):
        message = trame(commande, data1, data2, data3)
        with self.verrou:
            for essai in range(1, essais + 1):
                reponse = self._echange_brut(message)
                if self._reponse_valide(reponse):
                    return reponse
                recu = reponse.hex(' ') if reponse else "rien"
                self.journal(f"réponse incorrecte ({len(reponse)} octets : {recu}), essai {essai}/{essais}")
                self._purger()
        raise ErreurBoitier(f"réponse incorrecte : {len(reponse)} octets reçus au lieu de 6 ({recu})")

    def synchroniser(self, decalages=6):
        """Remet en phase l'échange avec le boîtier.

        Si le boîtier a gardé des octets d'une trame incomplète (parasite à l'ouverture du
        port, câble débranché pendant un échange…), toutes les trames suivantes sont
        décalées. On envoie une lecture sans effet (lecture HT voie 1) ; si la réponse est
        mauvaise, on envoie un octet nul pour décaler d'un cran, et on recommence.
        Les trames ainsi formées ne contiennent que les octets 23, 08, 00 et 3F :
        elles ne peuvent pas programmer une haute tension.
        """
        message = trame(CMD_LIRE_HT, 0)
        with self.verrou:
            self._purger(0.1)
            for decalage in range(decalages + 1):
                reponse = self._echange_brut(message, timeout=0.6)
                if self._reponse_valide(reponse):
                    if decalage:
                        self.journal(f"échange resynchronisé après {decalage} octet(s) de décalage")
                    return True
                self._purger(0.2)
                self.port.write(b"\x00")
                self._purger(0.2)
        return False

    def _lire_valeur(self, commande, index):
        r = self.echange(commande, index)
        return r[3] * 256 + r[4]

    # -- commandes de haut niveau --------------------------------------------
    def programmer_seuil(self, voie, seuil_mv):
        code = code_seuil(seuil_mv)
        self.echange(CMD_SEUIL, voie, (code & 0xF00) >> 8, code & 0xFF)
        return code

    def programmer_ht(self, voie, volts):
        code = code_ht(volts)
        self.echange(CMD_ECRIRE_HT, voie, (code & 0xF00) >> 8, code & 0xFF)
        return code

    def lire_ht(self, voie):
        return volts_depuis_adc_ht(self._lire_valeur(CMD_LIRE_HT, voie))

    def lire_voie(self, voie):
        return self._lire_valeur(CMD_LIRE_VOIE, voie)

    def lire_fonction(self, fonction):
        return self._lire_valeur(CMD_LIRE_FONCTION, fonction)

    def lire_viemuon_brut(self, index):
        return self._lire_valeur(CMD_LIRE_VIEMUON, index)

    def raz_voie(self, voie):
        self.echange(CMD_RAZ_VOIE, voie)

    def raz_fonction(self, fonction):
        self.echange(CMD_RAZ_FONCTION, fonction)

    def raz_viemuon(self, index):
        self.echange(CMD_RAZ_VIEMUON, index)

    def raz_tout(self):
        for v in range(4):
            self.raz_voie(v)
        for f in range(9):
            self.raz_fonction(f)
        for m in range(2):
            self.raz_viemuon(m)


# =============================================================================
#  Simulateur : un faux boîtier qui répond au même protocole, pour essayer le
#  logiciel sans le détecteur (option « Simulation » de l'interface).
# =============================================================================

def _poisson(lam):
    if lam <= 0:
        return 0
    if lam > 30:
        return max(0, int(round(random.gauss(lam, math.sqrt(lam)))))
    l, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= random.random()
        if p <= l:
            return k
        k += 1


def _sigmoide(x):
    return 1.0 / (1.0 + math.exp(-x))


class BoitierSimule:
    """Imite l'interface de serial.Serial (write / read / in_waiting / close)."""

    TAU_MUON_NS = 2197.0

    def __init__(self):
        self.seuil_code = [0] * 4
        self.ht_code = [0] * 4
        self.ht_reelle = [0.0] * 4
        self.voies = [0] * 4
        self.fonctions = [0] * 9
        self.viemuon = [0, 0]
        self.dernier = time.monotonic()
        self._sortie = b""
        self.is_open = True

    # -- physique très simplifiée --------------------------------------------
    def _efficacite(self, i):
        ht = self.ht_reelle[i]
        seuil_mv = self.seuil_code[i] / DAC_MAX_CODE * DAC_MAX_MV / GAIN_AMPLI_ENTREE
        return _sigmoide((ht - 750) / 45) * _sigmoide((70 - seuil_mv) / 12)

    def _bruit(self, i):
        ht = self.ht_reelle[i]
        seuil_mv = self.seuil_code[i] / DAC_MAX_CODE * DAC_MAX_MV / GAIN_AMPLI_ENTREE
        return 40 * _sigmoide((ht - 950) / 40) * math.exp(-seuil_mv / 15)

    def _avancer(self):
        maintenant = time.monotonic()
        dt = maintenant - self.dernier
        self.dernier = maintenant
        if dt <= 0:
            return
        for i in range(4):  # rampe de la HT (~200 V/s)
            cible = min(self.ht_code[i] / DAC_MAX_CODE * HT_DAC_PLEINE_ECHELLE, HT_COMMANDE_MAX) \
                * HT_MAX_VOLTS / HT_COMMANDE_MAX
            pas = 200 * dt
            self.ht_reelle[i] += max(-pas, min(pas, cible - self.ht_reelle[i]))
        eff = [self._efficacite(i) for i in range(4)]
        # Muons traversant la roue (raquettes 1, 2, 3) : sous-ensembles touchés
        motifs = [((0, 1, 2), 0.30), ((0, 1), 0.12), ((1, 2), 0.12), ((0, 2), 0.06),
                  ((0,), 0.16), ((1,), 0.10), ((2,), 0.14)]
        for touches, proportion in motifs:
            for _ in range(_poisson(14.0 * proportion * dt)):
                vus = {i for i in touches if random.random() < eff[i]}
                self._compter(vus)
        # Cylindre (voie 4) : muons, arrêts et désintégrations
        for _ in range(_poisson(6.0 * dt)):
            if random.random() < eff[3]:
                self._compter({3})
        if eff[3] > 0.05:
            for _ in range(_poisson(0.7 * dt * eff[3])):
                if random.random() < 0.55:      # post-impulsions du PM (~300 ns)
                    t = random.gauss(300, 30)
                else:
                    t = random.expovariate(1 / self.TAU_MUON_NS)
                ticks = int(t / HORLOGE_NS)
                if 0 < ticks < 65536 and self.viemuon[0] == 0:
                    self.viemuon[0] = ticks
        # Bruit non corrélé
        for i in range(4):
            n = _poisson(self._bruit(i) * dt)
            self.voies[i] = (self.voies[i] + n) & 0xFFFF
            if i == 0:
                self.fonctions[8] = (self.fonctions[8] + n) & 0xFFFF

    def _compter(self, vus):
        for i in vus:
            self.voies[i] = (self.voies[i] + 1) & 0xFFFF
        paires = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
        for k, (a, b) in enumerate(paires):
            if a in vus and b in vus:
                self.fonctions[k] = (self.fonctions[k] + 1) & 0xFFFF
        if {0, 1, 2} <= vus:
            self.fonctions[6] = (self.fonctions[6] + 1) & 0xFFFF
        if {0, 1, 2, 3} <= vus:
            self.fonctions[7] = (self.fonctions[7] + 1) & 0xFFFF
        if 0 in vus and 1 not in vus and 2 not in vus:
            self.fonctions[8] = (self.fonctions[8] + 1) & 0xFFFF

    # -- interface « port série » --------------------------------------------
    @property
    def in_waiting(self):
        return len(self._sortie)

    def reset_input_buffer(self):
        self._sortie = b""

    def write(self, donnees):
        time.sleep(0.0125)  # durée d'un échange réel à 9600 bauds
        if len(donnees) != 6 or donnees[0] != 0x23 or donnees[5] != 0x3F:
            return len(donnees)
        self._avancer()
        cmd, d1, d2, d3 = donnees[1], donnees[2], donnees[3], donnees[4]
        valeur = None
        if cmd == CMD_SEUIL and d1 < 4:
            self.seuil_code[d1] = (d2 << 8) | d3
        elif cmd == CMD_ECRIRE_HT and d1 < 4:
            self.ht_code[d1] = (d2 << 8) | d3
        elif cmd == CMD_LIRE_VOIE and d1 < 4:
            valeur = self.voies[d1]
        elif cmd == CMD_RAZ_VOIE and d1 < 4:
            self.voies[d1] = 0
        elif cmd == CMD_LIRE_FONCTION and d1 < 9:
            valeur = self.fonctions[d1]
        elif cmd == CMD_RAZ_FONCTION and d1 < 9:
            self.fonctions[d1] = 0
        elif cmd == CMD_LIRE_VIEMUON and d1 < 2:
            valeur = self.viemuon[d1]
        elif cmd == CMD_RAZ_VIEMUON and d1 < 2:
            self.viemuon[d1] = 0
        elif cmd == CMD_LIRE_HT and d1 < 4:
            v = self.ht_reelle[d1] / HT_FACTEUR_LECTURE / ADC_MAX_VOLTS * 2 ** ADC_BITS
            valeur = max(0, min(4095, int(v + random.uniform(0, 12))))
        if valeur is not None:
            d2, d3 = (valeur >> 8) & 0xFF, valeur & 0xFF
        self._sortie += bytes([0x23, cmd, d1, d2, d3, 0x3F])
        return 6

    def read(self, n=1):
        donnees, self._sortie = self._sortie[:n], self._sortie[n:]
        return donnees

    def close(self):
        self.is_open = False
