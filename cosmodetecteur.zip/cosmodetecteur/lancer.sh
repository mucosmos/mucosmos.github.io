#!/bin/sh
# Lance le logiciel du cosmodétecteur (laisser la fenêtre ouverte pendant l'utilisation)
cd "$(dirname "$0")"
# Python du système en priorité (c'est lui qui a pyserial installé par apt)
if [ -x /usr/bin/python3 ]; then PY=/usr/bin/python3; else PY=python3; fi
if ! "$PY" -c "import serial" 2>/dev/null; then
  echo "Le module pyserial manque. Tapez dans un terminal :"
  echo "    sudo apt install python3-serial"
  echo
fi
"$PY" cosmodetecteur.py "$@"
echo
echo "Logiciel arrêté. Appuyez sur Entrée pour fermer."
read _
